#!/usr/bin/env python3
"""Tiny dependency-free receiver and dashboard server for Raspberry Pi."""

import argparse
import hmac
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
STATE = {"metrics": None, "received_at": 0.0, "source_ip": None}
LOCK = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    server_version = "MonitorBridge/1.0"

    def send_bytes(self, status, content_type, body, cache="no-store"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status, data):
        self.send_bytes(status, "application/json; charset=utf-8", json.dumps(data).encode("utf-8"))

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/status":
            with LOCK:
                has_metrics = STATE["metrics"] is not None
                received_at = STATE["received_at"]
            host, port = self.server.server_address[:2]
            self.send_json(200, {
                "status": "ok",
                "service": "mac-agent",
                "listen": f"{host}:{port}",
                "uptime_seconds": round(time.time() - self.server.started_at, 2),
                "metrics_online": has_metrics and time.time() - received_at < self.server.stale_after,
            })
            return
        if path == "/api/metrics":
            with LOCK:
                metrics = STATE["metrics"]
                received_at = STATE["received_at"]
            self.send_json(200, {
                "online": bool(metrics) and time.time() - received_at < self.server.stale_after,
                "age_seconds": round(time.time() - received_at, 2) if received_at else None,
                "metrics": metrics,
            })
            return
        assets = {"/": ("dashboard/index.html", "text/html; charset=utf-8"),
                  "/app.js": ("dashboard/app.js", "text/javascript; charset=utf-8"),
                  "/style.css": ("dashboard/style.css", "text/css; charset=utf-8")}
        if path not in assets:
            self.send_error(404)
            return
        rel, content_type = assets[path]
        try:
            body = (ROOT / rel).read_bytes()
        except OSError:
            self.send_error(500)
            return
        self.send_bytes(200, content_type, body, "public, max-age=300" if path != "/" else "no-cache")

    def do_POST(self):
        if urlparse(self.path).path != "/api/metrics":
            self.send_error(404)
            return
        provided = self.headers.get("X-Monitor-Token", "")
        if not hmac.compare_digest(provided, self.server.token):
            self.send_json(401, {"error": "invalid token"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 256_000:
                raise ValueError("invalid body size")
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict) or data.get("version") != 1 or "host" not in data:
                raise ValueError("invalid payload")
        except (ValueError, json.JSONDecodeError):
            self.send_json(400, {"error": "invalid metrics payload"})
            return
        with LOCK:
            STATE.update(metrics=data, received_at=time.time(), source_ip=self.client_address[0])
        self.send_json(202, {"ok": True})

    def log_message(self, fmt, *args):
        if self.server.verbose:
            super().log_message(fmt, *args)


def parse_args():
    parser = argparse.ArgumentParser(description="树莓派实时性能仪表盘")
    parser.add_argument("--host", default=os.getenv("MONITOR_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("MONITOR_PORT", "8765")))
    parser.add_argument("--token", default=os.getenv("MONITOR_TOKEN"), help="电脑端使用的共享密钥")
    parser.add_argument("--stale-after", type=float, default=5.0, help="多少秒未收到数据视为离线")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    if not args.token or len(args.token) < 12:
        parser.error("请用 --token 设置至少 12 位的共享密钥")
    return args


def main():
    args = parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.token = args.token
    server.stale_after = args.stale_after
    server.verbose = args.verbose
    server.started_at = time.time()
    print(f"MonitorBridge 已启动：http://{args.host}:{args.port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
