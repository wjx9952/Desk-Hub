"""Compact native Home Assistant smart-home card. Credentials are never logged."""
import json
import logging
import math
import time
from pathlib import Path

from PyQt5.QtCore import Qt, QTimer, QUrl, QRectF, QPointF
from PyQt5.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PyQt5.QtWidgets import QComboBox, QFrame, QLabel, QPushButton, QWidget, QSlider

LOG = logging.getLogger('monitor.qt')
CONFIG = Path.home()/'.config/macbook-monitor-qt/homeassistant.json'
MIN_TARGET_C = 16
DEFAULT_LIGHT_ENTITY = 'light.tai_deng'
STALE_GRACE_SECONDS = 30
RETRY_DELAYS_SECONDS = (1, 2, 5, 8)


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


class HomeIcon(QWidget):
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor('#00cfee'),2.2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
        p.drawLine(QPointF(2,12),QPointF(self.width()/2,3));p.drawLine(QPointF(self.width()/2,3),QPointF(self.width()-2,12))
        p.drawRoundedRect(QRectF(5,11,self.width()-10,self.height()-14),2,2);p.drawRect(QRectF(self.width()/2-2,self.height()-10,4,7))
        p.end()


class AirConditionerIcon(QWidget):
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor('#00cfee'),1.8,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
        w,h=self.width(),self.height();p.drawRoundedRect(QRectF(2,4,w-4,h-8),3,3);p.drawLine(6,h-7,w-6,h-7)
        p.end()


class LampIcon(QWidget):
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor('#00cfee'),2.0,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
        w,h=self.width(),self.height()
        # Side-profile Mi desk-lamp silhouette: base, upright, angled neck and head.
        p.drawLine(QPointF(3,h-3),QPointF(13,h-3));p.drawLine(QPointF(8,h-4),QPointF(8,9))
        p.drawLine(QPointF(8,9),QPointF(14,4));p.drawLine(QPointF(14,4),QPointF(w-2,4))
        p.drawLine(QPointF(w-4,4),QPointF(w-2,6))
        p.end()


class HomePodIcon(QWidget):
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor('#00cfee'),2.0,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin))
        heights=(7,13,19,14,9)
        for i,height in enumerate(heights):
            x=3+i*(self.width()-6)/4
            p.drawLine(QPointF(x,(self.height()-height)/2),QPointF(x,(self.height()+height)/2))
        p.end()


class PowerButton(QPushButton):
    """Font-independent round power control with an explicit red/green state."""
    def __init__(self,parent=None):
        super().__init__('',parent);self.on=False;self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet('background:transparent;border:none')
    def set_on(self,on):
        self.on=bool(on);self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        diameter=min(self.width(),self.height())-2;left=(self.width()-diameter)/2;top=(self.height()-diameter)/2
        fill='#00a968' if self.on else '#a92d42'
        border='#31e19a' if self.on else '#fa6a79'
        if not self.isEnabled():fill,border='#172129','#44515b'
        p.setPen(QPen(QColor(border),1.5));p.setBrush(QColor(fill));p.drawEllipse(QRectF(left,top,diameter,diameter))
        cx=self.width()/2;cy=self.height()/2;p.setPen(QPen(QColor('#ffffff' if self.isEnabled() else '#74818c'),2.1,Qt.SolidLine,Qt.RoundCap))
        # Standard power symbol: the circular stroke opens at the top and the
        # vertical stroke sits centrally in that opening.
        p.drawArc(QRectF(cx-7,cy-7,14,14),135*16,270*16)
        p.drawLine(QPointF(cx,cy-9),QPointF(cx,cy-1));p.end()


class ControlIcon(QWidget):
    """Small line icons used instead of text labels on the compact controls."""
    def __init__(self,kind,parent=None):
        super().__init__(parent);self.kind=kind
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);w,h=self.width(),self.height();cx,cy=w/2,h/2
        color='#ffa627' if self.kind=='color_temp' else '#00cfee'
        p.setPen(QPen(QColor(color),1.8,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
        if self.kind=='brightness':
            p.drawEllipse(QRectF(cx-3.5,cy-3.5,7,7))
            for i in range(8):
                angle=math.pi*2*i/8;p.drawLine(QPointF(cx+math.cos(angle)*6,cy+math.sin(angle)*6),QPointF(cx+math.cos(angle)*9,cy+math.sin(angle)*9))
        elif self.kind=='mode':
            p.drawEllipse(QRectF(cx-6,cy-6,12,12));p.drawEllipse(QRectF(cx-2.5,cy-2.5,5,5))
            for i in range(8):
                angle=math.pi*2*i/8;p.drawLine(QPointF(cx+math.cos(angle)*6,cy+math.sin(angle)*6),QPointF(cx+math.cos(angle)*9,cy+math.sin(angle)*9))
        elif self.kind=='fan':
            p.drawEllipse(QRectF(cx-2,cy-2,4,4))
            for dx,dy in ((0,-5),(5,0),(0,5),(-5,0)):p.drawEllipse(QRectF(cx+dx-3,cy+dy-3,6,6))
        elif self.kind in ('color_temp','temperature'):
            p.drawEllipse(QRectF(cx-4,h-9,8,8));p.drawRoundedRect(QRectF(cx-2,2,4,h-10),2,2);p.drawLine(QPointF(cx,7),QPointF(cx,h-7))
        elif self.kind=='humidity':
            path=QPainterPath();path.moveTo(cx,2)
            path.cubicTo(cx-1.5,5.5,cx-7,10.5,cx-7,15)
            path.cubicTo(cx-7,23,cx+7,23,cx+7,15)
            path.cubicTo(cx+7,10.5,cx+1.5,5.5,cx,2);path.closeSubpath();p.drawPath(path)
        p.end()


class ClimatePanel(QFrame):
    """Smart Home panel with compact climate and desk-lamp controls."""
    def __init__(self,parent=None,config_path=CONFIG):
        super().__init__(parent);self.setObjectName('climatePanel')
        self.setStyleSheet('QFrame#climatePanel{background:#080d12;border:1px solid #24343f;border-radius:25px}')
        self.net=QNetworkAccessManager(self);self.reply=None;self.sensor_net=QNetworkAccessManager(self);self.sensor_reply=None
        self.closed=self.busy=self.valid=self.light_valid=False;self.last_ok=self.light_last_ok=0
        self.data,self.light_data,self.config={},{},{}
        self.pending={'brightness':0,'color_temp':0}
        self.failures={'climate':0,'light':0};self.retry_scheduled={'climate':False,'light':False}
        try:
            self.config=json.loads(Path(config_path).read_text())
            if not all(isinstance(self.config.get(k),str) and self.config[k] for k in ('url','entity','token')):self.config={}
        except (OSError,ValueError):pass
        configured_light=self.config.get('light_entity') if self.config else None
        self.light_entity=configured_light.strip() if isinstance(configured_light,str) and configured_light.strip() else DEFAULT_LIGHT_ENTITY
        self.temperature_entity=(self.config.get('temperature_entity') if self.config else None) or 'sensor.temperature_humidity_sensor_4d3a_temperature'
        self.humidity_entity=(self.config.get('humidity_entity') if self.config else None) or 'sensor.temperature_humidity_sensor_4d3a_humidity'

        self.icon=HomeIcon(self);self.title=self.label('Smart Home',18,True)
        self.status=self.label('● Connecting',9,True,'#94a8bb',Qt.AlignCenter)
        self.status.setStyleSheet('color:#94a8bb;background:#101920;border:1px solid #34424c;border-radius:10px')
        self.updated=self.label('Updated N/A',9,False,'#94a8bb',Qt.AlignRight)
        self.ac_card=self.frame();self.lamp_card=self.frame();self.temperature_card=self.frame();self.humidity_card=self.frame();self.homepod_card=self.frame()
        self.ac_icon=AirConditionerIcon(self.ac_card);self.ac_title=self.label('Air Conditioner',10,True,parent=self.ac_card)
        self.lamp_icon=LampIcon(self.lamp_card);self.lamp_title=self.label('Desk Lamp',10,True,parent=self.lamp_card)

        self.room_label=self.label('Room',8,False,'#94a8bb',Qt.AlignCenter,self.ac_card)
        self.room=self.label('N/A',15,True,'#eef3fa',Qt.AlignCenter,self.ac_card)
        self.target_label=self.label('Target',8,False,'#94a8bb',Qt.AlignCenter,self.ac_card)
        self.target=self.label('N/A',22,True,'#eef3fa',Qt.AlignCenter,self.ac_card)
        self.minus=self.button('−',self.ac_card);self.plus=self.button('+',self.ac_card)
        for temperature_button in (self.minus,self.plus):
            temperature_button.setStyleSheet(temperature_button.styleSheet().replace('font-size:10px','font-size:16px'))
        self.minus.clicked.connect(lambda:self.adjust(-1));self.plus.clicked.connect(lambda:self.adjust(1))
        self.power=PowerButton(self.ac_card);self.power.setAccessibleName('air-conditioner-power');self.power.clicked.connect(self.toggle_power)
        choice_names=[('hvac','Mode'),('fan','Fan')]
        self.choice_frames={key:self.control_frame(self.ac_card) for key,_ in choice_names}
        self.choice_labels={key:self.label(name,7,False,'#94a8bb',Qt.AlignLeft,self.choice_frames[key]) for key,name in choice_names}
        self.choices={key:self.combo(name,self.choice_frames[key]) for key,name in choice_names}
        self.mode_icon=ControlIcon('mode',self.choice_frames['hvac']);self.fan_icon=ControlIcon('fan',self.choice_frames['fan'])
        for key,combo in self.choices.items():combo.activated.connect(lambda index,k=key:self.select(k,index))

        self.light_power=PowerButton(self.lamp_card);self.light_power.setAccessibleName('desk-lamp-power');self.light_power.clicked.connect(self.toggle_light)
        self.brightness_label=self.label('Brightness',8,parent=self.lamp_card)
        self.brightness_value=self.label('N/A',8,True,'#eef3fa',Qt.AlignRight,self.lamp_card)
        self.brightness_icon=ControlIcon('brightness',self.lamp_card)
        self.brightness=self.slider(self.lamp_card,1,100,'brightness',self.set_brightness)
        self.brightness_minus=self.button('−',self.lamp_card);self.brightness_plus=self.button('+',self.lamp_card)
        self.brightness_minus.clicked.connect(lambda:self.adjust_light_slider('brightness',-1));self.brightness_plus.clicked.connect(lambda:self.adjust_light_slider('brightness',1))
        self.temperature_label=self.label('Color Temperature',8,parent=self.lamp_card)
        self.temperature_value=self.label('N/A',8,True,'#eef3fa',Qt.AlignRight,self.lamp_card)
        self.color_temp_icon=ControlIcon('color_temp',self.lamp_card)
        self.color_temp=self.slider(self.lamp_card,2600,5000,'color_temp',self.set_color_temp)
        self.color_temp_minus=self.button('−',self.lamp_card);self.color_temp_plus=self.button('+',self.lamp_card)
        self.color_temp_minus.clicked.connect(lambda:self.adjust_light_slider('color_temp',-1));self.color_temp_plus.clicked.connect(lambda:self.adjust_light_slider('color_temp',1))
        self.color_temp.setStyleSheet(self.color_temp.styleSheet().replace('#00cfee','qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #ff9f31,stop:.52 #ffe19a,stop:1 #56bdff)'))

        self.ac_widgets=[self.minus,self.plus,self.power,*self.choices.values()]
        self.temperature_title=self.label('',9,True,parent=self.temperature_card);self.temperature_title.hide()
        self.humidity_title=self.label('',9,True,parent=self.humidity_card);self.humidity_title.hide()
        self.temperature_icon=ControlIcon('temperature',self.temperature_card);self.humidity_icon=ControlIcon('humidity',self.humidity_card)
        self.environment_temperature=self.label('N/A',18,True,'#eef3fa',Qt.AlignCenter,self.temperature_card)
        self.environment_humidity=self.label('N/A',18,True,'#eef3fa',Qt.AlignCenter,self.humidity_card)
        self.environment_updated=self.label('',8,False,'#94a8bb',Qt.AlignCenter,self)
        self.environment_updated.hide()
        self.homepod_icon=HomePodIcon(self.homepod_card);self.homepod_title=self.label('HomePod',10,True,parent=self.homepod_card)
        self.homepod_art=QLabel(self.homepod_card);self.homepod_art.setAlignment(Qt.AlignCenter);self.homepod_art.setStyleSheet('background:#101628;border:1px solid #29404e;border-radius:9px')
        self.homepod_track=self.label('No playback information',9,True,'#eef3fa',Qt.AlignCenter,self.homepod_card)
        self.homepod_subtitle=self.label('HomePod unavailable',8,False,'#94a8bb',Qt.AlignCenter,self.homepod_card)
        self.homepod_volume_value=self.label('',8,True,'#eef3fa',Qt.AlignRight,self.homepod_card);self.homepod_volume_value.hide()
        for widget in (self.room_label,self.room,self.target_label,self.brightness_label,self.brightness_value,self.temperature_label,self.temperature_value):widget.hide()
        self.light_widgets=[self.light_power,self.brightness,self.color_temp,self.brightness_minus,self.brightness_plus,self.color_temp_minus,self.color_temp_plus]
        self.enable(False);self.enable_light(False)
        self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(5000);QTimer.singleShot(0,self.refresh)

    def frame(self):
        item=QFrame(self);item.setObjectName('smartCard');item.setStyleSheet('QFrame#smartCard{background:#0a1118;border:1px solid #20313c;border-radius:13px}');return item

    def control_frame(self,parent):
        item=QFrame(parent);item.setObjectName('controlBox')
        item.setStyleSheet('QFrame#controlBox{background:#0c141c;border:1px solid #29404e;border-radius:8px}')
        return item

    def label(self,text,pixels,bold=False,color='#eef3fa',align=Qt.AlignLeft,parent=None):
        item=QLabel(text,parent or self);item.setAlignment(align|Qt.AlignVCenter)
        item.setStyleSheet(f'color:{color};background:transparent;border:none;font-size:{pixels}px;font-weight:{700 if bold else 400}');return item

    def button(self,text,parent,accent=False):
        item=QPushButton(text,parent);item.setCursor(Qt.PointingHandCursor)
        bg='qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #07b6e8,stop:1 #00d3f2)' if accent else '#111b23'
        item.setStyleSheet(f'QPushButton{{color:#eef3fa;background:{bg};border:1px solid #29404e;border-radius:8px;font-size:10px;font-weight:600}}QPushButton:pressed{{background:#305267}}QPushButton:disabled{{color:#667480;background:#111820}}');return item

    def combo(self,name,parent):
        item=QComboBox(parent);item.setAccessibleName(name)
        item.setStyleSheet('QComboBox{color:#00cfee;background:transparent;border:none;padding:0 12px 0 0;font-size:9px;font-weight:600}QComboBox:disabled{color:#667480}QComboBox QAbstractItemView{color:#eef3fa;background:#15202b;selection-background-color:#305267;min-height:24px}');return item

    def slider(self,parent,minimum,maximum,key,callback):
        item=QSlider(Qt.Horizontal,parent);item.setRange(minimum,maximum);item.setAccessibleName(key)
        item.setStyleSheet('QSlider::groove:horizontal{height:4px;background:#263441;border-radius:2px}QSlider::sub-page:horizontal{background:#00cfee;border-radius:2px}QSlider::handle:horizontal{background:white;border-radius:6px;width:12px;margin:-5px 0}')
        item.sliderPressed.connect(lambda:self.pending.update({key:float('inf')}))
        item.sliderReleased.connect(lambda:(self.pending.update({key:time.monotonic()+5}),callback(item.value())))
        return item

    def resizeEvent(self,event):
        sx,sy=self.width()/453,self.height()/306
        def place(widget,x,y,w,h):widget.setGeometry(round(x*sx),round(y*sy),round(w*sx),round(h*sy))
        place(self.icon,13,13,25,25);place(self.title,43,11,178,27);place(self.status,371,13,70,21);place(self.updated,297,36,144,15)
        place(self.ac_card,10,56,210,122);place(self.lamp_card,10,184,210,112);place(self.temperature_card,227,56,104,48);place(self.humidity_card,337,56,106,48);place(self.homepod_card,227,110,216,186)
        self.ac_icon.setGeometry(8,7,21,20);self.ac_title.setGeometry(34,5,125,24);self.power.setGeometry(171,4,30,30)
        self.minus.setGeometry(19,34,34,32);self.target.setGeometry(59,28,92,42);self.plus.setGeometry(157,34,34,32)
        self.choice_frames['hvac'].setGeometry(10,77,91,35);self.choice_frames['fan'].setGeometry(109,77,91,35)
        self.mode_icon.setGeometry(7,8,18,18);self.choice_labels['hvac'].setGeometry(30,2,45,13);self.choices['hvac'].setGeometry(30,14,54,18)
        self.fan_icon.setGeometry(7,8,18,18);self.choice_labels['fan'].setGeometry(30,2,45,13);self.choices['fan'].setGeometry(30,14,54,18)
        self.lamp_icon.setGeometry(8,7,21,21);self.lamp_title.setGeometry(34,5,125,24);self.light_power.setGeometry(171,5,32,32)
        self.brightness_icon.setGeometry(8,46,22,22);self.brightness_minus.setGeometry(35,45,28,25);self.brightness.setGeometry(68,48,98,19);self.brightness_plus.setGeometry(174,45,28,25)
        self.color_temp_icon.setGeometry(8,79,22,22);self.color_temp_minus.setGeometry(35,78,28,25);self.color_temp.setGeometry(68,81,98,19);self.color_temp_plus.setGeometry(174,78,28,25)
        self.temperature_icon.setGeometry(9,13,18,21);self.environment_temperature.setGeometry(31,8,65,32)
        self.humidity_icon.setGeometry(9,12,19,23);self.environment_humidity.setGeometry(31,8,67,32)
        self.homepod_icon.setGeometry(10,7,21,20);self.homepod_title.setGeometry(37,5,100,23)
        self.homepod_art.setGeometry(10,34,86,86);self.homepod_track.setGeometry(103,34,103,24);self.homepod_subtitle.setGeometry(103,58,103,36)
        super().resizeEvent(event)

    def enable(self,enabled):
        for widget in self.ac_widgets:widget.setEnabled(enabled)
        if enabled:
            a=self.data.get('attributes',{})
            for key,combo in self.choices.items():combo.setEnabled(bool(a.get(key+'_modes')))
            value=a.get('temperature');minimum,maximum=self.target_bounds(a)
            self.minus.setEnabled(numeric(value) and value>minimum);self.plus.setEnabled(numeric(value) and value<maximum)

    def enable_light(self,enabled):
        for widget in self.light_widgets:widget.setEnabled(enabled)

    def set_light_power_style(self,on):
        self.light_power.set_on(on)

    def update_homepod(self,data,art,online):
        title=data.get('title') if isinstance(data,dict) else None
        subtitle=' · '.join(str(data.get(k)) for k in ('artist','album') if data.get(k)) if isinstance(data,dict) else ''
        self.homepod_track.setText(title or 'No playback information')
        self.homepod_subtitle.setText(subtitle or ('Ready' if online else 'HomePod unavailable'))
        if isinstance(art,QPixmap) and not art.isNull():
            self.homepod_art.setPixmap(art.scaled(self.homepod_art.size(),Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation))
        else:self.homepod_art.setPixmap(QPixmap())

    def set_homepod_volume(self,value,online):
        # The slider position is the sole volume indicator in the compact card.
        pass

    def target_bounds(self,a):
        minimum=max(MIN_TARGET_C,a.get('min_temp') if numeric(a.get('min_temp')) else MIN_TARGET_C)
        maximum=a.get('max_temp') if numeric(a.get('max_temp')) else 30
        return minimum,max(minimum,maximum)

    def request(self,path,callback,body=None):
        if self.closed or self.reply is not None or not self.config:return
        req=QNetworkRequest(QUrl(self.config['url'].rstrip('/')+path));req.setAttribute(QNetworkRequest.RedirectPolicyAttribute,QNetworkRequest.ManualRedirectPolicy)
        req.setRawHeader(b'Authorization',('Bearer '+self.config['token']).encode());req.setHeader(QNetworkRequest.ContentTypeHeader,'application/json')
        reply=self.net.get(req) if body is None else self.net.post(req,json.dumps(body).encode());self.reply=reply
        timer=QTimer(reply);timer.setSingleShot(True);timer.timeout.connect(reply.abort);timer.start(7000)
        def finished():
            timer.stop();self.reply=None
            try:
                error_code=reply.error();error_text=reply.errorString();ok=error_code==QNetworkReply.NoError;code=reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
                try:data=json.loads(bytes(reply.readAll()))
                except (ValueError,UnicodeDecodeError):data=None;ok=False
                context={'path':path,'http_status':code,'network_error':int(error_code),'error':error_text}
                if not ok:LOG.warning('Smart Home request failed: path=%s http_status=%s network_error=%s error=%r',path,code,error_code,error_text)
                callback(ok,data,context)
            except Exception:
                LOG.exception('Smart Home callback failed');self.busy=False;self.sync_enabled()
            finally:reply.deleteLater()
        reply.finished.connect(finished)

    def refresh(self):
        if self.busy or self.reply is not None or self.closed:return
        if not self.config:self.set_online(False);return
        self.request('/api/states/'+self.config['entity'],self.receive)

    def refresh_light(self):
        if not self.busy and self.reply is None and not self.closed:self.request('/api/states/'+self.light_entity,self.receive_light)

    def state_failure(self,kind,context=None):
        """Keep the last usable controls briefly while Home Assistant reconnects."""
        self.failures[kind]+=1
        last=self.last_ok if kind=='climate' else self.light_last_ok
        age=time.monotonic()-last if last else float('inf')
        if age>STALE_GRACE_SECONDS:
            if kind=='climate':self.valid=False
            else:self.light_valid=False
        delay=RETRY_DELAYS_SECONDS[min(self.failures[kind]-1,len(RETRY_DELAYS_SECONDS)-1)]
        details=context or {}
        LOG.warning('Smart Home %s state unavailable: failures=%s age=%.1fs grace=%ss retry_in=%ss path=%s http_status=%s error=%r',kind,self.failures[kind],age,STALE_GRACE_SECONDS,delay,details.get('path'),details.get('http_status'),details.get('error'))
        if not self.retry_scheduled[kind] and not self.closed:
            self.retry_scheduled[kind]=True
            def retry():
                self.retry_scheduled[kind]=False
                if kind=='climate':self.refresh()
                else:self.refresh_light()
            QTimer.singleShot(delay*1000,retry)

    def state_ok(self,kind):
        self.failures[kind]=0

    def set_online(self,online):
        self.status.setText('● Live' if online else ('● Partial' if self.valid or self.light_valid else '● Offline'))
        live=online or self.valid or self.light_valid
        self.status.setStyleSheet('color:#00df97;background:#08271f;border:1px solid #14543e;border-radius:10px' if live else 'color:#94a8bb;background:#171c22;border:1px solid #34424c;border-radius:10px')

    def receive(self,ok,data,context=None):
        ok=ok and isinstance(data,dict) and data.get('entity_id')==self.config.get('entity') and isinstance(data.get('attributes'),dict)
        ok=bool(ok and data.get('state') not in (None,'unknown','unavailable'))
        if not ok:self.state_failure('climate',context)
        else:self.valid=True;self.state_ok('climate')
        if ok:
            self.data=data;self.last_ok=time.monotonic();a=data['attributes'];degrees=lambda v:f'{v:g}°C' if numeric(v) else 'N/A'
            self.room.setText(degrees(a.get('current_temperature')));self.target.setText(degrees(a.get('temperature')));self.power.set_on(data['state']!='off')
            for key,combo in self.choices.items():
                options=a.get(key+'_modes') or [];combo.blockSignals(True);combo.clear()
                for option in options:combo.addItem(str(option).replace('_',' ').title(),option)
                current=data['state'] if key=='hvac' else a.get(key+'_mode');combo.setCurrentIndex(combo.findData(current));combo.blockSignals(False)
        self.sync_enabled();self.refresh_light()

    def receive_light(self,ok,data,context=None):
        ok=ok and isinstance(data,dict) and data.get('entity_id')==self.light_entity and isinstance(data.get('attributes'),dict)
        ok=bool(ok and data.get('state') not in (None,'unknown','unavailable'))
        if not ok:self.state_failure('light',context)
        else:self.light_valid=True;self.state_ok('light')
        if ok:
            self.light_data=data;self.light_last_ok=time.monotonic();a=data['attributes'];self.set_light_power_style(data['state']=='on')
            brightness=round(a.get('brightness',0)*100/255) if numeric(a.get('brightness')) else None
            kelvin=a.get('color_temp_kelvin');minimum=a.get('min_color_temp_kelvin');maximum=a.get('max_color_temp_kelvin')
            if numeric(minimum) and numeric(maximum):self.color_temp.setRange(round(minimum),round(maximum))
            if numeric(brightness) and time.monotonic()>=self.pending['brightness']:self.brightness.setValue(brightness)
            if numeric(kelvin) and time.monotonic()>=self.pending['color_temp']:self.color_temp.setValue(round(kelvin))
            self.brightness_value.setText(f'{brightness}%' if numeric(brightness) else 'N/A');self.temperature_value.setText(f'{round(kelvin)} K' if numeric(kelvin) else 'N/A')
            self.updated.setText('Updated '+time.strftime('%H:%M:%S'))
        self.sync_enabled();self.refresh_sensors()

    def refresh_sensors(self):
        if self.closed or not self.config or self.sensor_reply is not None:return
        self.request_sensor('temperature',self.temperature_entity)

    def request_sensor(self,kind,entity):
        req=QNetworkRequest(QUrl(self.config['url'].rstrip('/')+'/api/states/'+entity));req.setRawHeader(b'Authorization',('Bearer '+self.config['token']).encode())
        reply=self.sensor_net.get(req);self.sensor_reply=reply;timer=QTimer(reply);timer.setSingleShot(True);timer.timeout.connect(reply.abort);timer.start(7000)
        def finished():
            timer.stop();self.sensor_reply=None
            try:
                ok=reply.error()==QNetworkReply.NoError
                try:data=json.loads(bytes(reply.readAll()))
                except (ValueError,UnicodeDecodeError):data=None;ok=False
                if ok and isinstance(data,dict) and data.get('state') not in (None,'unknown','unavailable'):
                    value=str(data.get('state'));self.environment_temperature.setText(value+'°C' if kind=='temperature' else self.environment_temperature.text());self.environment_humidity.setText(value+'%' if kind=='humidity' else self.environment_humidity.text());self.environment_updated.setText('Updated '+time.strftime('%H:%M:%S'))
                elif not ok:LOG.warning('Smart Home sensor request failed: kind=%s error=%r',kind,reply.errorString())
                if kind=='temperature' and not self.closed:self.request_sensor('humidity',self.humidity_entity)
            finally:reply.deleteLater()
        reply.finished.connect(finished)

    def sync_enabled(self):
        self.set_online(self.valid and self.light_valid);self.enable(self.valid and not self.busy);self.enable_light(self.light_valid and not self.busy)

    def command(self,domain,service,fields,kind):
        valid,last=(self.valid,self.last_ok) if kind=='climate' else (self.light_valid,self.light_last_ok)
        if self.busy or not valid or time.monotonic()-last>12:return
        self.busy=True;self.sync_enabled();entity=self.config['entity'] if kind=='climate' else self.light_entity
        def finished(ok,data,context=None):
            self.busy=False
            if not ok:
                LOG.warning('Smart Home command failed: service=%s.%s kind=%s http_status=%s error=%r',domain,service,kind,(context or {}).get('http_status'),(context or {}).get('error'))
                self.state_failure(kind,context)
            else:
                LOG.info('Smart Home command accepted: service=%s.%s kind=%s; refreshing state',domain,service,kind)
            self.sync_enabled()
            QTimer.singleShot(250,self.refresh)
        self.request(f'/api/services/{domain}/{service}',finished,dict(fields,entity_id=entity))

    def select(self,key,index):
        value=self.choices[key].itemData(index)
        if value in (self.data.get('attributes',{}).get(key+'_modes') or []):self.command('climate','set_'+key+'_mode',{key+'_mode':value},'climate')

    def adjust(self,direction):
        a=self.data.get('attributes',{});value=a.get('temperature');step=a.get('target_temp_step',1)
        if not numeric(value) or not numeric(step) or step<=0:return
        minimum,maximum=self.target_bounds(a);target=max(minimum,min(maximum,value+direction*step))
        if target!=value:self.command('climate','set_temperature',{'temperature':target},'climate')

    def toggle_power(self):self.command('climate','turn_on' if self.data.get('state')=='off' else 'turn_off',{},'climate')
    def toggle_light(self):self.command('light','turn_off' if self.light_data.get('state')=='on' else 'turn_on',{},'light')
    def set_brightness(self,value):self.brightness_value.setText(f'{value}%');self.command('light','turn_on',{'brightness':round(value*255/100)},'light')
    def set_color_temp(self,value):self.temperature_value.setText(f'{value} K');self.command('light','turn_on',{'color_temp_kelvin':value},'light')

    def adjust_light_slider(self,key,direction):
        slider=self.brightness if key=='brightness' else self.color_temp
        step=5 if key=='brightness' else max(1,round((slider.maximum()-slider.minimum())*.05))
        value=max(slider.minimum(),min(slider.maximum(),slider.value()+direction*step));slider.setValue(value)
        self.pending[key]=time.monotonic()+5
        (self.set_brightness if key=='brightness' else self.set_color_temp)(value)

    def shutdown(self):
        self.closed=True;self.timer.stop()
        if self.reply is not None:self.reply.finished.disconnect();self.reply.abort();self.reply.deleteLater();self.reply=None
        if self.sensor_reply is not None:self.sensor_reply.finished.disconnect();self.sensor_reply.abort();self.sensor_reply.deleteLater();self.sensor_reply=None
