#!/usr/bin/env python3
"""Native Qt receiver. Uses existing monitor/bridge APIs; no web engine."""
import argparse
import json
import logging
from logging.handlers import RotatingFileHandler
import math
from pathlib import Path
import sys
import time
from urllib.parse import quote

from PyQt5.QtCore import Qt, QRectF, QPointF, QPoint, QTimer, QUrl, QSettings, QEasingCurve, QPropertyAnimation
from PyQt5.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QBrush, QConicalGradient, QPixmap
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QSlider, QFrame, QLabel
from climate import ClimatePanel

WHITE = '#eef3fa'
MUTED = '#94a8bb'
CYAN = '#00cfee'
GREEN = '#00df97'
PURPLE = '#bd29ff'
ORANGE = '#ffa627'
LOG = logging.getLogger('monitor.qt')


def setup_logging():
    directory = Path.home()/'.local/state/macbook-monitor-qt'
    directory.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(directory/'monitor.log', maxBytes=1024*1024, backupCount=2)
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)
    def report(kind, value, trace):
        LOG.error('Unhandled Qt callback', exc_info=(kind, value, trace))
        app = QApplication.instance()
        if app:
            for window in app.topLevelWidgets():
                if isinstance(window, Monitor):
                    window.message('An operation failed. The monitor is still running; see monitor.log.')
    sys.excepthook = report


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def unit(value, suffix='', precision=0):
    return f'{value:.{precision}f}{suffix}' if number(value) else 'N/A'


def size(value, speed=False):
    if not number(value):
        return 'N/A'
    index = 0
    while abs(value) >= 1024 and index < 4:
        value /= 1024
        index += 1
    return f'{value:.{1 if index >= 2 else 0}f} '+['B', 'KB', 'MB', 'GB', 'TB'][index]+('/s' if speed else '')


def stamp(value, date=False):
    if not number(value) or value <= 0:
        return 'N/A'
    try:
        return time.strftime('%d %b %H:%M' if date else '%H:%M:%S', time.localtime(value))
    except (ValueError, OverflowError, OSError):
        return 'N/A'


class SwipeStrip(QWidget):
    """Invisible bottom-edge gesture target; an upward swipe opens quick controls."""
    def __init__(self, parent, callback):
        super().__init__(parent); self.callback=callback; self.start=None
        self.setCursor(Qt.OpenHandCursor); self.setAttribute(Qt.WA_StyledBackground,False)
    def mousePressEvent(self,event):
        self.start=event.pos();self.setCursor(Qt.ClosedHandCursor);event.accept()
    def mouseReleaseEvent(self,event):
        if self.start is not None and event.pos().y()-self.start.y()<=-28:self.callback()
        self.start=None;self.setCursor(Qt.OpenHandCursor);event.accept()


class QuickMenu(QFrame):
    def __init__(self,parent,brightness,lock_screen,close_app,dismiss):
        super().__init__(parent);self.setObjectName('quickMenu')
        self.setStyleSheet('''QFrame#quickMenu{background:#101820;border:1px solid #39505f;border-radius:24px}
            QLabel{color:#eef3fa;background:transparent;border:none} QPushButton{color:#eef3fa;background:#17242e;border:1px solid #36505f;border-radius:14px;font-size:16px;padding:8px}
            QPushButton:pressed{background:#31556a} QPushButton#danger{color:#ffb4bc;border-color:#823c48;background:#30171d}
            QSlider::groove:horizontal{height:7px;background:#263441;border-radius:3px} QSlider::sub-page:horizontal{background:#00cfee;border-radius:3px}
            QSlider::handle:horizontal{background:white;border-radius:10px;width:20px;margin:-7px 0}''')
        title=QLabel('Display Controls',self);title.setStyleSheet('font-size:22px;font-weight:700');title.setGeometry(28,16,250,30)
        hint=QLabel('Swipe up from the bottom to open',self);hint.setStyleSheet('color:#94a8bb;font-size:11px');hint.setGeometry(28,46,260,18)
        label=QLabel('Brightness',self);label.setStyleSheet('font-size:14px');label.setGeometry(28,78,100,28)
        self.slider=QSlider(Qt.Horizontal,self);self.slider.setRange(5,100);self.slider.setGeometry(125,77,430,30)
        self.slider.sliderPressed.connect(lambda:setattr(self,'dragging',True));self.slider.sliderReleased.connect(self.send_brightness)
        self.dragging=False;self.brightness=brightness
        self.percent=QLabel('N/A',self);self.percent.setAlignment(Qt.AlignRight|Qt.AlignVCenter);self.percent.setGeometry(567,78,55,28)
        self.slider.valueChanged.connect(lambda value:self.percent.setText(str(value)+'%'))
        lock=QPushButton('Lock Screen',self);lock.setGeometry(28,126,180,48);lock.clicked.connect(lock_screen)
        done=QPushButton('Back to Monitor',self);done.setGeometry(222,126,210,48);done.clicked.connect(dismiss)
        close=QPushButton('Close App',self);close.setObjectName('danger');close.setGeometry(446,126,176,48);close.clicked.connect(close_app)
        self.animation=QPropertyAnimation(self,b'pos',self);self.animation.setDuration(260);self.animation.setEasingCurve(QEasingCurve.OutCubic)
    def paintEvent(self,event):
        super().paintEvent(event)
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(QPen(QColor(255,255,255,90),3,Qt.SolidLine,Qt.RoundCap));p.drawLine(self.width()//2-24,8,self.width()//2+24,8)
    def send_brightness(self):
        self.dragging=False;self.brightness(self.slider.value())
    def sync(self,value):
        if number(value) and not self.dragging:
            value=round(value);self.slider.setValue(value);self.percent.setText(str(value)+'%')


class Monitor(QWidget):
    def __init__(self, mac, bridge):
        super().__init__()
        self.setWindowTitle('MacBook Monitor · Qt')
        self.setMinimumSize(740, 160)
        self.resize(1480, 320)
        self.mac = mac.rstrip('/')
        self.bridge = bridge.rstrip('/')
        self.net = QNetworkAccessManager(self)
        self.replies = {}
        self.closing = False
        self.data = {key: {} for key in ['mac', 'homepod', 'nas', 'screen']}
        self.online = dict.fromkeys(['mac', 'codex', 'homepod', 'nas'], False)
        self.settings = QSettings('MacBookMonitor', 'QtReceiver')
        self.updated = {k: float(self.settings.value('updated/'+k, 0) or 0) for k in self.online}
        self.inflight, self.controls, self.pending = set(), {}, {}
        self.art_id, self.art, self.art_retry = None, QPixmap(), 0
        self.activity, self.completed_at = 'idle', 0
        self.feedback, self.feedback_until = '', 0
        self.started = time.monotonic()
        self.climate = ClimatePanel(self)
        self.add_button('previous', '◀|', (1131, 205, 30, 30), lambda: self.action('previous'))
        self.add_button('play', '▶', (1168, 200, 40, 40), lambda: self.action('play_pause'))
        self.add_button('next', '|▶', (1214, 205, 30, 30), lambda: self.action('next'))
        self.add_button('volume_down', '−', (1043, 278, 28, 20), lambda: self.adjust_volume(-1))
        self.add_slider('volume', (1075, 279, 127, 18), 0, lambda v: self.action('set_volume', volume=v))
        self.add_button('volume_up', '+', (1207, 278, 28, 20), lambda: self.adjust_volume(1))
        self.quick_menu = QuickMenu(self, lambda value:self.screen_action('set_brightness',brightness=value), lambda:self.screen_action('off'), self.close, self.hide_quick_menu)
        self.quick_menu.hide()
        self.swipe_strip = SwipeStrip(self,self.show_quick_menu)
        for key, interval in [('mac', 1000), ('homepod', 3500), ('nas', 30000), ('screen', 10000)]:
            timer = QTimer(self)
            timer.timeout.connect(lambda k=key: self.refresh(k))
            timer.start(interval)
            QTimer.singleShot(0, lambda k=key: self.refresh(k))
        self.animation = QTimer(self)
        self.animation.timeout.connect(self.tick)
        self.animation.start(33)
        self.layout_controls()

    def add_button(self, key, label, rect, callback):
        button = QPushButton(label, self)
        button.setCursor(Qt.PointingHandCursor)
        button.setAccessibleName(key)
        button.clicked.connect(callback)
        button.setStyleSheet('QPushButton{color:#edf4ff;background:#15202b;border:1px solid #29404e;border-radius:12px;font-size:15px;padding:0}QPushButton:pressed{background:#305267}QPushButton:disabled{color:#667480} ' + ('QPushButton{background:#8026e9}' if key == 'play' else ''))
        self.controls[key] = button, QRectF(*rect)

    def add_slider(self, key, rect, minimum, callback):
        slider = QSlider(Qt.Horizontal, self)
        slider.setRange(minimum, 100)
        slider.setAccessibleName(key)
        slider.setStyleSheet('QSlider::groove:horizontal{height:5px;background:#263441;border-radius:2px}QSlider::sub-page:horizontal{background:#00cfee;border-radius:2px}QSlider::handle:horizontal{background:white;border-radius:8px;width:16px;margin:-6px 0}')
        slider.sliderPressed.connect(lambda: self.pending.update({key: float('inf')}))
        slider.sliderReleased.connect(lambda: self.slider_send(key, callback))
        self.controls[key] = slider, QRectF(*rect)

    def slider_send(self, key, callback):
        self.pending[key] = time.monotonic()+5
        callback(self.controls[key][0].value())

    def layout_controls(self):
        self.scale = min(self.width()/1480, self.height()/320)
        self.dx = (self.width()-1480*self.scale)/2
        self.dy = (self.height()-320*self.scale)/2
        for widget, rect in self.controls.values():
            widget.setGeometry(int(self.dx+rect.x()*self.scale), int(self.dy+rect.y()*self.scale), max(1,int(rect.width()*self.scale)), max(1,int(rect.height()*self.scale)))
        self.climate.setGeometry(int(self.dx+811*self.scale),int(self.dy+7*self.scale),int(443*self.scale),int(306*self.scale))
        # Keep the gesture target at the true bottom edge.  The previous 35px
        # overlay intercepted the HomePod and Smart Home sliders above it.
        self.swipe_strip.setGeometry(int(self.dx),int(self.dy+300*self.scale),int(1480*self.scale),max(16,int(20*self.scale)))
        menu_x=int(self.dx+(1480-650)*self.scale/2);menu_y=int(self.dy+(320-190-10)*self.scale)
        self.quick_menu.resize(max(420,int(650*self.scale)),max(150,int(190*self.scale)))
        if self.quick_menu.isVisible() and self.quick_menu.animation.state()!=QPropertyAnimation.Running:self.quick_menu.move(menu_x,menu_y)
        if not self.quick_menu.isVisible():self.swipe_strip.raise_()

    def show_quick_menu(self):
        if self.quick_menu.isVisible():return
        self.quick_menu.show();self.quick_menu.raise_()
        x=int(self.dx+(1480-650)*self.scale/2);end_y=int(self.dy+(320-190-10)*self.scale)
        self.quick_menu.animation.stop();self.quick_menu.move(x,end_y+self.quick_menu.height()+15)
        self.quick_menu.animation.setStartValue(self.quick_menu.pos());self.quick_menu.animation.setEndValue(QPoint(x,end_y));self.quick_menu.animation.start()
        self.sync_visibility()

    def hide_quick_menu(self):
        self.quick_menu.animation.stop();self.quick_menu.hide();self.sync_visibility()

    def sync_visibility(self):
        for name,(widget,_) in self.controls.items():
            widget.setVisible(True)
            if name in ('previous','play','next','volume','volume_down','volume_up'):
                widget.setEnabled(self.online['homepod'] and 'action' not in self.inflight and not self.quick_menu.isVisible())
        self.climate.setVisible(True)
        self.climate.enable(self.climate.valid and not self.climate.busy and not self.quick_menu.isVisible())
        self.swipe_strip.setVisible(True);self.swipe_strip.raise_()
        if self.quick_menu.isVisible():self.quick_menu.raise_()
        else:self.swipe_strip.raise_()

    def resizeEvent(self, event):
        self.layout_controls()

    def request(self, key, url, callback, body=None, raw=False, timeout=24000, headers=None):
        if self.closing or key in self.inflight:
            return
        self.inflight.add(key)
        req = QNetworkRequest(QUrl(url))
        req.setRawHeader(b'Cache-Control', b'no-cache')
        req.setHeader(QNetworkRequest.ContentTypeHeader, 'application/json')
        for name, value in (headers or {}).items():
            req.setRawHeader(str(name).encode(), str(value).encode())
        if body is None:
            reply = self.net.get(req)
        else:
            encoded = json.dumps(body).encode()
            reply = self.net.post(req, encoded)
        self.replies[key] = reply
        timer = QTimer(reply)
        timer.setSingleShot(True)
        timer.timeout.connect(reply.abort)
        timer.start(timeout)
        def done():
            timer.stop()
            self.inflight.discard(key)
            try:
                content = bytes(reply.readAll())
                ok = reply.error() == QNetworkReply.NoError
                try:
                    payload = content if raw else json.loads(content)
                    if not raw and not isinstance(payload, dict):
                        raise ValueError('Expected a JSON object')
                except (ValueError, UnicodeDecodeError):
                    payload = {'error': 'Invalid response from device'}
                    ok = False
                if not ok and not raw and not payload.get('error'):
                    payload['error'] = reply.errorString()
                callback(ok, payload)
            except Exception:
                LOG.exception('Network callback failed: %s', key)
                self.message('Device response could not be processed. Please try again.')
            finally:
                self.replies.pop(key, None)
                reply.deleteLater()
                self.update()
        reply.finished.connect(done)

    def state(self, key, online, timestamp=None):
        self.online[key] = bool(online)
        if online and number(timestamp) and timestamp > self.updated[key]:
            self.updated[key] = timestamp
            self.settings.setValue('updated/'+key, timestamp)

    def refresh(self, key):
        if key == 'mac':
            url = self.mac+'/api/status'
        else:
            url = self.bridge+{'homepod':'/status','nas':'/nas-status','screen':'/screen-status'}[key]
        self.request(key, url, lambda ok, data: self.receive(key, ok, data), timeout=6000 if key == 'mac' else 24000)

    def receive(self, key, ok, data):
        ok = ok and isinstance(data, dict)
        data = data if ok else {}
        if key in ('homepod','nas'):
            ok = ok and bool(data.get('online'))
        self.data[key] = data if ok else {}
        now = time.time()
        if key != 'screen':
            self.state(key, ok, now if ok else None)
        if key == 'mac':
            codex = data.get('codex_usage') or {}
            self.state('codex', ok and (data.get('services') or {}).get('codex_connected'), codex.get('updated_at'))
            control = codex.get('control') or {}
            activity = control.get('activity', 'idle') if self.online['codex'] else 'idle'
            if activity == 'completed' and self.activity != 'completed':
                self.completed_at = time.monotonic()
            self.activity = activity
        elif key == 'homepod':
            self.controls['play'][0].setText('Ⅱ' if str(data.get('state','')).lower() == 'playing' else '▶')
            for name in ('previous','play','next','volume','volume_down','volume_up'):
                self.controls[name][0].setEnabled(ok and 'action' not in self.inflight)
            self.sync_slider('volume', data.get('volume'))
            self.climate.update_homepod(data,self.art,ok)
            self.climate.set_homepod_volume(data.get('volume'),ok)
            art_id = data.get('artwork_id') if ok else None
            if art_id != self.art_id:
                self.art_id, self.art, self.art_retry = art_id, QPixmap(), 0
            if art_id and self.art.isNull() and time.monotonic() > self.art_retry:
                self.art_retry = time.monotonic()+20
                self.request('art', self.bridge+'/artwork?id='+quote(str(art_id), safe=''), lambda success, image: self.artwork(art_id, success, image), raw=True)
        elif key == 'screen':
            supported = ok and bool(data.get('supported'))
            self.quick_menu.slider.setEnabled(supported)
            self.quick_menu.sync(data.get('brightness_percent'))

    def sync_slider(self, key, value):
        widget = self.controls[key][0]
        if number(value) and not widget.isSliderDown() and time.monotonic() >= self.pending.get(key, 0):
            widget.setValue(round(value))

    def adjust_volume(self,direction):
        slider=self.controls['volume'][0]
        value=max(slider.minimum(),min(slider.maximum(),slider.value()+direction*5))
        slider.setValue(value);self.pending['volume']=time.monotonic()+5
        self.climate.set_homepod_volume(value,True)
        self.action('set_volume',volume=value)

    def artwork(self, art_id, ok, content):
        if art_id == self.art_id and ok:
            self.art.loadFromData(content)
            self.climate.update_homepod(self.data.get('homepod',{}),self.art,self.online['homepod'])

    def message(self, text):
        self.feedback, self.feedback_until = str(text)[:300], time.monotonic()+10
        LOG.info('Operation feedback: %s', self.feedback)
        self.update()

    def action(self, action, **params):
        if not self.online['homepod'] or 'action' in self.inflight:
            return
        def finish(ok, data):
            success = ok and data.get('ok') is True
            if not success:
                self.message(data.get('error', 'HomePod control failed'))
                self.pending['volume'] = 0
            for name in ('previous','play','next','volume','volume_down','volume_up'):
                self.controls[name][0].setEnabled(self.online['homepod'])
            self.refresh('homepod')
        for name in ('previous','play','next','volume','volume_down','volume_up'):
            self.controls[name][0].setEnabled(False)
        self.request('action', self.bridge+'/action', finish, {'action':action, **params})

    def screen_action(self, action, **params):
        def finish(ok, data):
            if not ok:
                self.message(data.get('error', 'Display control failed'))
            self.refresh('screen')
        self.request('screen-action', self.bridge+'/screen-action', finish, {'action':action, **params})

    def tick(self):
        if self.activity in ('working','waiting') or (self.activity == 'completed' and time.monotonic()-self.completed_at < 61):
            self.update()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.showNormal()
        elif event.key() == Qt.Key_F11:
            self.showNormal() if self.isFullScreen() else self.showFullScreen()

    def closeEvent(self, event):
        self.closing = True
        self.climate.shutdown()
        for timer in self.findChildren(QTimer):
            timer.stop()
        for reply in list(self.replies.values()):
            reply.finished.disconnect()
            reply.abort()
            reply.deleteLater()
        self.replies.clear()
        self.inflight.clear()
        self.settings.sync()
        super().closeEvent(event)

    def box(self, p, rect, radius=15, fill='#0c1117', stroke='#20313c'):
        p.setPen(QPen(QColor(stroke), .8))
        p.setBrush(QColor(fill))
        p.drawRoundedRect(QRectF(*rect), radius, radius)

    def text(self, p, rect, value, pixels=14, color=WHITE, bold=False, align=Qt.AlignLeft, wrap=False):
        p.setFont(QFont('DejaVu Sans', -1))
        font = p.font(); font.setPixelSize(pixels); font.setBold(bold); p.setFont(font)
        p.setPen(QColor(color))
        value = str(value)
        if not wrap:
            value = p.fontMetrics().elidedText(value, Qt.ElideRight, int(rect[2]))
        p.drawText(QRectF(*rect), align | Qt.AlignVCenter | (Qt.TextWordWrap if wrap else 0), value)

    def icon(self,p,kind,rect,color=CYAN):
        x,y,w,h=rect;p.save();p.translate(x,y);p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(color),2,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
        if kind=='laptop':
            p.drawRoundedRect(QRectF(3,2,w-6,h-8),2,2);p.drawLine(1,h-3,w-1,h-3);p.drawLine(6,h-7,6,h-3);p.drawLine(w-6,h-7,w-6,h-3)
        elif kind=='codex':
            # Official Codex app mark, simplified as a crisp line icon for this UI.
            mark=QPainterPath();mark.moveTo(9,23)
            mark.cubicTo(5,23,3,20,5,16)
            mark.cubicTo(2,13,3,8,8,7)
            mark.cubicTo(8,3,12,1,16,4)
            mark.cubicTo(19,1,24,3,24,7)
            mark.cubicTo(28,8,29,12,26,15)
            mark.cubicTo(28,19,25,23,21,22)
            mark.cubicTo(19,26,14,27,11,23)
            mark.cubicTo(10,24,9,24,9,23);mark.closeSubpath();p.drawPath(mark)
            p.drawLine(QPointF(9,10),QPointF(13,14));p.drawLine(QPointF(13,14),QPointF(9,18))
            p.drawLine(QPointF(16,18),QPointF(21,18))
        elif kind=='wave':
            for i,height in enumerate((10,18,27,20,12,22,14)):
                xx=2+i*(w-4)/6;p.drawLine(QPointF(xx,(h-height)/2),QPointF(xx,(h+height)/2))
        elif kind=='chip':
            p.drawRoundedRect(QRectF(6,5,w-12,h-10),3,3)
            for i in range(4):
                xx=9+i*(w-18)/3;p.drawLine(QPointF(xx,1),QPointF(xx,5));p.drawLine(QPointF(xx,h-5),QPointF(xx,h-1))
                yy=8+i*(h-16)/3;p.drawLine(QPointF(2,yy),QPointF(6,yy));p.drawLine(QPointF(w-6,yy),QPointF(w-2,yy))
            p.drawEllipse(QRectF(w/2-3,h/2-3,6,6))
        elif kind in ('down','up'):
            if kind=='down':p.drawLine(QPointF(w/2,2),QPointF(w/2,h-4));p.drawLine(QPointF(w/2,h-4),QPointF(4,h-11));p.drawLine(QPointF(w/2,h-4),QPointF(w-4,h-11))
            else:p.drawLine(QPointF(w/2,h-2),QPointF(w/2,4));p.drawLine(QPointF(w/2,4),QPointF(4,11));p.drawLine(QPointF(w/2,4),QPointF(w-4,11))
        elif kind=='fan':
            p.drawEllipse(QRectF(w/2-2,h/2-2,4,4))
            for dx,dy in ((0,-7),(7,0),(0,7),(-7,0)):p.drawEllipse(QRectF(w/2+dx-4,h/2+dy-4,8,8))
        elif kind=='drive':
            p.drawRoundedRect(QRectF(5,2,w-10,h-4),3,3);p.drawLine(QPointF(7,h*.58),QPointF(w-7,h*.58));p.drawEllipse(QRectF(9,h*.7,3,3));p.drawEllipse(QRectF(15,h*.7,3,3))
        elif kind=='thermo':
            p.drawEllipse(QRectF(w/2-4,h-9,8,8));p.drawRoundedRect(QRectF(w/2-2,2,4,h-10),2,2);p.drawLine(QPointF(w/2,7),QPointF(w/2,h-7))
        elif kind=='battery':
            p.drawRoundedRect(QRectF(3,6,w-8,h-12),3,3);p.drawLine(QPointF(w-5,h/2-3),QPointF(w-5,h/2+3));p.drawLine(QPointF(7,h/2),QPointF(w-12,h/2))
        elif kind=='diskio':
            p.drawEllipse(QRectF(3,3,w-6,h-6));p.drawEllipse(QRectF(w/2-3,h/2-3,6,6))
        elif kind=='server':
            for yy in (2,h/2+1):
                p.drawRoundedRect(QRectF(3,yy,w-6,h/2-4),2,2);p.drawEllipse(QRectF(7,yy+3,3,3));p.drawLine(QPointF(13,yy+4.5),QPointF(w-6,yy+4.5))
        p.restore()

    def header(self, p, x, width, title, key, kind, pixels=19, status_width=72):
        self.icon(p,kind,(x+14,19,30,27),CYAN)
        right = x+width-15-status_width
        self.text(p, (x+51, 16, right-(x+51)-5, 31), title, pixels, WHITE, True)
        self.box(p, (right,18,status_width,22), 11, '#08271f' if self.online[key] else '#171c22', '#14543e' if self.online[key] else '#34424c')
        self.text(p, (right+3,18,status_width-6,22), '● Live' if self.online[key] else '● Offline', 10, GREEN if self.online[key] else MUTED, True, Qt.AlignCenter)
        self.text(p, (x+width-123,40,108,18), 'Updated '+stamp(self.updated[key]), 10, MUTED, align=Qt.AlignRight)

    def progress(self, p, rect, percent, color):
        self.box(p, rect, 3, '#25303e', '#25303e')
        if number(percent):
            x,y,w,h = rect
            if percent > 0:
                self.box(p, (x,y,max(2,w*max(0,min(100,percent))/100),h), 3, color, color)

    def paintEvent(self, event):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor('#020508'))
        p.translate(self.dx,self.dy); p.scale(self.scale,self.scale)
        # Seven-pixel outer margins and seven-pixel inter-panel gaps.  The
        # left and right cards now share the same corner centres as the
        # inset rainbow frame (outer r=29, inner r=25, four-pixel offset).
        for rect in [(7,7,560,306),(574,7,230,306),(811,7,443,306),(1261,7,212,306)]:
            self.box(p,rect,25,'#080d12','#24343f')
        self.header(p,7,560,'MacBook Monitor','mac','laptop')
        self.header(p,574,230,'Codex','codex','codex',18)
        self.header(p,811,225,'HomePod','homepod','wave',16,58)
        d=self.data['mac']; fans=d.get('fans') or []; network=d.get('network') or {}; disk=d.get('disk') or {}; temps=d.get('temperatures') or {}
        values=[('CPU',unit(d.get('cpu_percent'),'%'),'chip',CYAN),('GPU',unit(d.get('gpu_percent'),'%'),'chip',PURPLE),('Download',size(network.get('download_bytes_per_sec'),True),'down',CYAN),('Upload',size(network.get('upload_bytes_per_sec'),True),'up',CYAN),('Fan 1',unit(fans[0].get('rpm') if len(fans)>0 else None,' RPM'),'fan',CYAN),('Fan 2',unit(fans[1].get('rpm') if len(fans)>1 else None,' RPM'),'fan',CYAN),('Disk Read',size(disk.get('read_bytes_per_sec'),True),'drive',CYAN),('Disk Write',size(disk.get('write_bytes_per_sec'),True),'drive',ORANGE),('CPU Temp',unit(temps.get('cpu_celsius'),'°C',1),'thermo',ORANGE),('Battery Temp',unit(temps.get('battery_celsius'),'°C',1),'battery',GREEN)]
        for i,(label,value,icon,color) in enumerate(values):
            x,y=19+(i%2)*107,65+(i//2)*47
            self.box(p,(x,y,101,41),10)
            self.icon(p,icon,(x+6,y+8,21,25),color)
            self.text(p,(x+31,y+2,68,15),label,9,MUTED)
            self.text(p,(x+31,y+17,68,21),value,12,WHITE,True)
        self.box(p,(234,65,320,229),15)
        self.icon(p,'diskio',(245,74,20,20),WHITE)
        self.text(p,(271,69,148,28),'Disk I/O Top 5',15,WHITE,True)
        self.text(p,(428,70,54,26),'Read',10,MUTED,align=Qt.AlignRight)
        self.text(p,(488,70,55,26),'Write',10,MUTED,align=Qt.AlignRight)
        for i,app in enumerate((d.get('top_disk_applications') or [])[:5]):
            y=101+i*37
            p.setPen(QColor('#23303a'));p.drawLine(QPointF(245,y-2),QPointF(543,y-2))
            self.text(p,(245,y,18,30),i+1,12,WHITE,True)
            self.text(p,(267,y,151,30),app.get('application_name') or 'N/A',12,WHITE,True)
            self.text(p,(423,y,59,30),size(app.get('read_bytes')),10,CYAN,True,Qt.AlignRight)
            self.text(p,(486,y,57,30),size(app.get('write_bytes')),10,ORANGE,True,Qt.AlignRight)
        c=d.get('codex_usage') or {}; control=c.get('control') or {}
        self.box(p,(587,65,204,43),12)
        self.text(p,(598,67,112,16),'Current Model',9,MUTED)
        self.text(p,(598,84,116,20),control.get('model_display_name') or control.get('model') or 'N/A',13,WHITE,True)
        self.text(p,(716,76,65,23),self.activity.title(),10,GREEN,True,Qt.AlignRight)
        for i,(name,key,color) in enumerate([('5h','five_hour',CYAN),('7d','seven_day',PURPLE)]):
            y=114+i*61; q=c.get(key) or {}
            self.box(p,(587,y,204,55),12)
            self.text(p,(598,y+3,100,23),name,13,WHITE,True)
            self.text(p,(720,y+3,60,23),unit(q.get('remaining_percent'),'%'),18,WHITE,True,Qt.AlignRight)
            self.progress(p,(598,y+29,182,5),q.get('remaining_percent'),color)
            self.text(p,(598,y+36,182,17),'Resets at '+stamp(q.get('resets_at'),True),9,MUTED)
        self.box(p,(587,235,204,68),12)
        self.text(p,(598,239,125,23),'↻  Reset Credits',12,WHITE,True)
        self.text(p,(724,239,56,23),str(c.get('reset_credits_available','N/A'))+' left',12,GREEN,True,Qt.AlignRight)
        expiries=c.get('reset_credit_expiries') or []
        for i,item in enumerate(expiries[:3]):
            self.text(p,(598,263+i*13,182,14),f'{i+1}. Expires '+stamp(item.get('expires_at'),True),9,MUTED)
        h=self.data['homepod']; self.box(p,(858,68,112,112),15,'#101628')
        if not self.art.isNull():
            p.save();path=QPainterPath();path.addRoundedRect(QRectF(858,68,112,112),15,15);p.setClipPath(path)
            art=self.art.scaled(112,112,Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation)
            p.drawPixmap(858+(112-art.width())//2,68+(112-art.height())//2,art);p.restore()
        else:
            self.text(p,(858,90,112,68),'♫',45,PURPLE,align=Qt.AlignCenter)
        self.text(p,(813,184,201,24),h.get('title') or 'No playback information',14,WHITE,True,Qt.AlignCenter)
        self.text(p,(813,208,201,19),' · '.join(str(h.get(k)) for k in ('artist','album') if h.get(k)) or h.get('state','HomePod unavailable'),10,MUTED,align=Qt.AlignCenter)
        n=self.data['nas']
        self.icon(p,'server',(1273,19,25,27),CYAN)
        self.text(p,(1303,16,100,31),'NAS Storage',14,WHITE,True)
        self.box(p,(1416,18,46,22),11,'#08271f' if self.online['nas'] else '#171c22','#14543e' if self.online['nas'] else '#34424c')
        self.text(p,(1418,18,42,22),'● Live' if self.online['nas'] else '● Off',9,GREEN if self.online['nas'] else MUTED,True,Qt.AlignCenter)
        self.text(p,(1350,40,112,18),'Updated '+stamp(self.updated['nas']),9,MUTED,align=Qt.AlignRight)
        self.box(p,(1273,65,188,99),13)
        self.text(p,(1284,69,165,18),'Available',10,MUTED)
        self.text(p,(1284,88,165,34),size(n.get('free_bytes')),25,WHITE,True)
        self.text(p,(1284,123,165,17),size(n.get('used_bytes'))+' used of '+size(n.get('total_bytes')),9,MUTED)
        self.progress(p,(1284,148,165,5),n.get('used_percent'),CYAN)
        for y,title,status,address in [(171,'Local Network','Ready' if self.online['nas'] else 'Unavailable',n.get('lan_ip_address')),(233,'Remote Access','Tailscale Ready' if n.get('remote_online') else 'Not connected',n.get('remote_address'))]:
            self.box(p,(1273,y,188,55),12)
            self.text(p,(1284,y+2,165,15),title,9,MUTED)
            self.text(p,(1284,y+17,165,17),status,10,GREEN if 'Ready' in status else MUTED,True)
            self.text(p,(1284,y+34,165,16),address or 'N/A',8,MUTED)
        self.lights(p)
        p.end()

    def lights(self,p):
        t=time.monotonic()-self.started
        state=self.activity
        if state == 'completed' and time.monotonic()-self.completed_at>=60:
            return
        if state not in ('working','waiting','completed'):
            return
        clip=QPainterPath();clip.addRoundedRect(QRectF(2,2,1476,316),30,30)
        p.save();p.setClipPath(clip)
        gradient=QConicalGradient(QPointF(740,160), (t*72)%360)
        colors=['#ff40d8','#a52cff','#246aff','#00deee','#20eda0','#ffd06e','#ff4778','#ff40d8']
        for i,color in enumerate(colors):gradient.setColorAt(i/(len(colors)-1),QColor(color))
        pulse=.5+.5*math.sin(t*(7 if state=='waiting' else 2.6))
        brush=QBrush(gradient) if state=='working' else QBrush(QColor(ORANGE if state=='waiting' else GREEN))
        for width,opacity in [(24,.035),(18,.05),(12,.08),(8,.12),(4,.3),(2,1)]:
            p.setOpacity(opacity*(1 if state=='working' else .3+.7*pulse))
            p.setPen(QPen(brush,width,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin));p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(QRectF(3,3,1474,314),29,29)
        p.restore()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mac',default='http://192.168.3.15:8765')
    parser.add_argument('--bridge',default='http://127.0.0.1:8766')
    parser.add_argument('--windowed',action='store_true')
    parser.add_argument('--screenshot')
    parser.add_argument('--quick-menu',action='store_true',help='Open quick controls for visual verification')
    args=parser.parse_args()
    setup_logging()
    LOG.info('Qt monitor starting')
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    app=QApplication(sys.argv)
    window=Monitor(args.mac,args.bridge)
    window.showNormal() if args.windowed else window.showFullScreen()
    if args.quick_menu:
        QTimer.singleShot(100,window.show_quick_menu)
    if args.screenshot:
        QTimer.singleShot(8000,lambda:(window.grab().save(args.screenshot),app.quit()))
    return app.exec_()


if __name__=='__main__':
    sys.exit(main())
