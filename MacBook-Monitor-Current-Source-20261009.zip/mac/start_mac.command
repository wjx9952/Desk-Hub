#!/bin/zsh
set -e
cd "${0:A:h}"

if [[ ! -d .venv ]]; then
  echo "首次运行，正在安装采集组件…"
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt
fi

read "PI_IP?请输入树莓派 IP（例如 192.168.1.50）: "
read -s "TOKEN?请输入共享密钥（至少 12 位）: "
echo

if [[ -z "$PI_IP" || ${#TOKEN} -lt 12 ]]; then
  echo "IP 不能为空，密钥不能少于 12 位。"
  exit 2
fi

echo "正在连接 http://${PI_IP}:8765，按 Control-C 停止。"
exec .venv/bin/python desktop_agent.py --server "http://${PI_IP}:8765" --token "$TOKEN"

