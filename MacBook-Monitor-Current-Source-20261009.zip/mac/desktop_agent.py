#!/usr/bin/env python3
"""Collect Activity Monitor-style metrics and send them to a Raspberry Pi."""

import argparse
import ctypes
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from types import SimpleNamespace

try:
    import psutil
except ImportError:
    print("缺少 psutil，请运行: python3 -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(2)


class RUsageInfoV2(ctypes.Structure):
    """macOS rusage_info_v2 from <sys/resource.h>."""

    _fields_ = [
        ("ri_uuid", ctypes.c_uint8 * 16),
        ("ri_user_time", ctypes.c_uint64),
        ("ri_system_time", ctypes.c_uint64),
        ("ri_pkg_idle_wkups", ctypes.c_uint64),
        ("ri_interrupt_wkups", ctypes.c_uint64),
        ("ri_pageins", ctypes.c_uint64),
        ("ri_wired_size", ctypes.c_uint64),
        ("ri_resident_size", ctypes.c_uint64),
        ("ri_phys_footprint", ctypes.c_uint64),
        ("ri_proc_start_abstime", ctypes.c_uint64),
        ("ri_proc_exit_abstime", ctypes.c_uint64),
        ("ri_child_user_time", ctypes.c_uint64),
        ("ri_child_system_time", ctypes.c_uint64),
        ("ri_child_pkg_idle_wkups", ctypes.c_uint64),
        ("ri_child_interrupt_wkups", ctypes.c_uint64),
        ("ri_child_pageins", ctypes.c_uint64),
        ("ri_child_elapsed_abstime", ctypes.c_uint64),
        ("ri_diskio_bytesread", ctypes.c_uint64),
        ("ri_diskio_byteswritten", ctypes.c_uint64),
    ]


def macos_process_io(pid):
    """Read per-process disk byte totals using macOS's native libproc API."""
    if platform.system() != "Darwin":
        return None
    try:
        libproc = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        function = libproc.proc_pid_rusage
        function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
        function.restype = ctypes.c_int
        info = RUsageInfoV2()
        if function(int(pid), 2, ctypes.byref(info)) != 0:  # RUSAGE_INFO_V2
            return None
        return int(info.ri_diskio_bytesread), int(info.ri_diskio_byteswritten)
    except (AttributeError, OSError):
        return None


def process_io_totals(proc):
    """Return cumulative (read_bytes, write_bytes), or None if unsupported."""
    method = getattr(proc, "io_counters", None)
    if callable(method):
        try:
            counters = method()
            return int(getattr(counters, "read_bytes", 0)), int(getattr(counters, "write_bytes", 0))
        except (OSError, PermissionError, psutil.AccessDenied, NotImplementedError):
            pass
    return macos_process_io(proc.pid)


def bytes_per_second(current, previous, elapsed):
    if previous is None or elapsed <= 0:
        return {"sent": 0.0, "recv": 0.0}
    return {
        "sent": max(0.0, (current.bytes_sent - previous.bytes_sent) / elapsed),
        "recv": max(0.0, (current.bytes_recv - previous.bytes_recv) / elapsed),
    }


def process_snapshot(previous_io=None, elapsed=0.0, limit=7, io_limit=5):
    previous_io = previous_io or {}
    rows = []
    io_rows = []
    current_io = {}
    try:
        processes = psutil.process_iter(["pid", "name", "username", "memory_percent"])
        # Some sandboxed or managed Macs deny the system-wide process list.
        processes = list(processes)
    except (OSError, PermissionError, psutil.AccessDenied):
        return rows, io_rows, current_io
    for proc in processes:
        try:
            info = proc.info
            row = {
                "pid": info["pid"],
                "name": info.get("name") or "未知",
                "user": info.get("username") or "",
                "cpu": round(proc.cpu_percent(None), 1),
                "memory": round(info.get("memory_percent") or 0.0, 1),
            }
            rows.append(row)
            try:
                totals = process_io_totals(proc)
                if totals is None:
                    continue
                key = (info["pid"], proc.create_time())
                read_total, write_total = totals
                current_io[key] = (read_total, write_total)
                old = previous_io.get(key)
                if old and elapsed > 0:
                    read_rate = max(0.0, (read_total - old[0]) / elapsed)
                    write_rate = max(0.0, (write_total - old[1]) / elapsed)
                    if read_rate > 0 or write_rate > 0:
                        io_rows.append({
                            "pid": info["pid"],
                            "name": row["name"],
                            "read": read_rate,
                            "write": write_rate,
                        })
            except (AttributeError, OSError, PermissionError, psutil.AccessDenied, NotImplementedError):
                pass
        except (OSError, psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    active = sorted(rows, key=lambda row: (row["cpu"], row["memory"]), reverse=True)[:limit]
    applications = {}
    for row in io_rows:
        app = applications.setdefault(row["name"], {
            "name": row["name"], "pid": row["pid"], "count": 0, "read": 0.0, "write": 0.0
        })
        app["count"] += 1
        app["read"] += row["read"]
        app["write"] += row["write"]
    busiest_io = sorted(
        applications.values(), key=lambda row: row["read"] + row["write"], reverse=True
    )[:io_limit]
    return active, busiest_io, current_io


def disk_counters():
    try:
        return psutil.disk_io_counters()
    except (OSError, PermissionError, psutil.AccessDenied):
        return None


def fan_snapshot():
    """Return fan RPM when the operating system exposes a readable sensor."""
    if hasattr(psutil, "sensors_fans"):
        try:
            groups = psutil.sensors_fans() or {}
            fans = []
            for group, entries in groups.items():
                for index, entry in enumerate(entries, 1):
                    rpm = float(getattr(entry, "current", 0) or 0)
                    if rpm >= 0:
                        fans.append({
                            "label": getattr(entry, "label", "") or f"{group} {index}",
                            "rpm": round(rpm),
                        })
            if fans:
                return {"available": True, "fans": fans}
        except (OSError, PermissionError):
            pass

    if platform.system() == "Darwin":
        candidates = [
            shutil.which("smc"),
            "/Applications/smcFanControl.app/Contents/Resources/smc",
        ]
        for command in filter(None, candidates):
            if not os.path.isfile(command):
                continue
            try:
                result = subprocess.run(
                    [command, "-f"], capture_output=True, text=True, timeout=0.8, check=False
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            matches = re.findall(r"Fan\s*(\d+).*?(\d+(?:\.\d+)?)\s*(?:RPM|rpm)?", result.stdout)
            if matches:
                return {
                    "available": True,
                    "fans": [{"label": f"风扇 {index}", "rpm": round(float(rpm))} for index, rpm in matches],
                }
        return {"available": False, "fans": [], "reason": "Mac 未开放风扇传感器"}

    return {"available": False, "fans": [], "reason": "未检测到转速传感器"}


def collect(previous_net, previous_disk, previous_process_io, previous_time):
    now_mono = time.monotonic()
    elapsed = now_mono - previous_time
    net = psutil.net_io_counters()
    disk = disk_counters()
    processes, io_processes, current_process_io = process_snapshot(previous_process_io, elapsed)
    memory = psutil.virtual_memory()
    try:
        swap = psutil.swap_memory()
    except (OSError, PermissionError, psutil.AccessDenied):
        swap = SimpleNamespace(total=0, used=0, percent=0.0)
    try:
        boot_time = psutil.boot_time()
    except (OSError, PermissionError, psutil.AccessDenied):
        boot_time = time.time()
    boot = datetime.fromtimestamp(boot_time, tz=timezone.utc)
    load = list(os.getloadavg()) if hasattr(os, "getloadavg") else [0, 0, 0]
    payload = {
        "version": 1,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "host": {
            "name": socket.gethostname(),
            "os": f"{platform.system()} {platform.release()}",
            "architecture": platform.machine(),
            "boot_time": boot.isoformat(),
        },
        "cpu": {
            "total": psutil.cpu_percent(None),
            "per_core": psutil.cpu_percent(None, percpu=True),
            "count": psutil.cpu_count() or 0,
            "load": load,
        },
        "memory": {
            "total": memory.total,
            "used": memory.used,
            "available": memory.available,
            "percent": memory.percent,
            "swap_total": swap.total,
            "swap_used": swap.used,
            "swap_percent": swap.percent,
        },
        "network": bytes_per_second(net, previous_net, elapsed),
        "disk_io": {
            "read": max(0.0, (disk.read_bytes - previous_disk.read_bytes) / elapsed) if disk and previous_disk and elapsed > 0 else 0.0,
            "write": max(0.0, (disk.write_bytes - previous_disk.write_bytes) / elapsed) if disk and previous_disk and elapsed > 0 else 0.0,
            "read_total": int(disk.read_bytes) if disk else 0,
            "write_total": int(disk.write_bytes) if disk else 0,
            "processes": io_processes,
        },
        "fans": fan_snapshot(),
        "processes": processes,
    }
    return payload, net, disk, current_process_io, now_mono


def post(url, token, payload, timeout):
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(
        url.rstrip("/") + "/api/metrics",
        data=data,
        method="POST",
        headers={"Content-Type": "application/json", "X-Monitor-Token": token},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        if response.status != 202:
            raise RuntimeError(f"服务器返回 HTTP {response.status}")


def parse_args():
    parser = argparse.ArgumentParser(description="将电脑性能数据实时发送到树莓派")
    parser.add_argument("--server", default=os.getenv("MONITOR_SERVER"), help="例如 http://192.168.1.50:8765")
    parser.add_argument("--token", default=os.getenv("MONITOR_TOKEN"), help="与树莓派相同的共享密钥")
    parser.add_argument("--interval", type=float, default=float(os.getenv("MONITOR_INTERVAL", "1")), help="采样间隔秒数")
    parser.add_argument("--once", action="store_true", help="只发送一次，用于测试")
    args = parser.parse_args()
    if not args.server or not args.token:
        parser.error("必须提供 --server 和 --token（也可用 MONITOR_SERVER / MONITOR_TOKEN）")
    if args.interval < 0.25:
        parser.error("--interval 不能小于 0.25 秒")
    return args


def main():
    args = parse_args()
    previous_net = psutil.net_io_counters()
    previous_disk = disk_counters()
    previous_time = time.monotonic()
    # Prime psutil's CPU counters so the first frame is meaningful.
    psutil.cpu_percent(None)
    psutil.cpu_percent(None, percpu=True)
    _, _, previous_process_io = process_snapshot()
    time.sleep(min(0.1, args.interval))
    failures = 0
    while True:
        started = time.monotonic()
        payload, previous_net, previous_disk, previous_process_io, previous_time = collect(
            previous_net, previous_disk, previous_process_io, previous_time
        )
        try:
            post(args.server, args.token, payload, max(2.0, args.interval * 2))
            if failures:
                print("已重新连接树莓派。", flush=True)
            failures = 0
        except (urllib.error.URLError, TimeoutError, RuntimeError) as exc:
            failures += 1
            if failures == 1 or failures % 10 == 0:
                print(f"发送失败（第 {failures} 次）: {exc}", file=sys.stderr, flush=True)
        if args.once:
            return 0 if failures == 0 else 1
        time.sleep(max(0.0, args.interval - (time.monotonic() - started)))


if __name__ == "__main__":
    raise SystemExit(main())
