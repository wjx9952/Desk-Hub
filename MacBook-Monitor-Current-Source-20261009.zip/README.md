# MacBook Monitor Dashboard

A native PyQt dashboard for a Raspberry Pi 5 and an ultrawide 11.9-inch touchscreen. It combines Mac telemetry, Codex usage, HomePod controls, Home Assistant climate/lighting/sensors, NAS capacity, display controls, and animated activity lighting.

This repository is a sanitized source snapshot. It intentionally contains no Home Assistant access token, Xiaomi device token, SSH key, password, cookie, or Codex authentication data.

![Current Raspberry Pi UI](docs/current-ui.png)

## Layout

- `mac/` — Mac telemetry collector.
- `raspberry-pi/` — the current native Qt touchscreen application and user service.
- `server/` — the authenticated telemetry receiver.
- `home-assistant/custom_components/` — local integrations used by the Smart Home card.
- `docs/design-reference.png` — the approved visual direction for the next deployed UI revision.

## Raspberry Pi requirements

- Raspberry Pi OS with a graphical session
- Python 3
- PyQt5
- A 1480×320-compatible display layout
- Home Assistant reachable over the local network for Smart Home controls

Install the Qt files under a directory such as:

```text
/home/<user>/.local/lib/macbook-monitor-qt/
```

Install the launcher as:

```text
/home/<user>/.local/bin/macbook-monitor-qt
```

Adjust paths and the user in `raspberry-pi/macbook-monitor-qt.service`, then enable it as a user service.

## Home Assistant configuration

Copy `raspberry-pi/homeassistant.example.json` to:

```text
~/.config/macbook-monitor-qt/homeassistant.json
```

Replace every placeholder locally. Never commit the real file.

## Mac telemetry

Create a virtual environment and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r mac/requirements.txt
python3 mac/desktop_agent.py \
  --server http://RASPBERRY_PI_IP:8765 \
  --token 'A_RANDOM_SHARED_SECRET'
```

Run the receiver with the same shared secret:

```bash
python3 server/pi_server.py --token 'A_RANDOM_SHARED_SECRET'
```

## Security

- Keep the telemetry and Home Assistant APIs on a trusted LAN or VPN.
- Do not expose ports directly to the public internet.
- Keep `homeassistant.json`, tokens, keys, logs, and device credentials outside Git.
- The previous Accessibility/AXPress Codex approval experiment is not part of this repository or the active Qt flow.

