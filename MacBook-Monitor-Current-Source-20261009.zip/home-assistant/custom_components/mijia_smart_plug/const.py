DOMAIN = "mijia_smart_plug"

CONF_NAME = "name"
CONF_MAC = "mac"
CONF_MODEL = "model"

DEFAULT_NAME = "Mijia Smart Plug 3"

PROPERTY_MAPPING = {
    "on": {"siid": 2, "piid": 1},
    "energy": {"siid": 11, "piid": 1},
    "power": {"siid": 11, "piid": 2},
    "temperature": {"siid": 12, "piid": 2},
}
