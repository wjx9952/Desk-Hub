from __future__ import annotations

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import CONF_MAC, DOMAIN
from .entity import MijiaSmartPlugEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    async_add_entities([MijiaSmartPlugSwitch(hass.data[DOMAIN][entry.entry_id], entry)])


class MijiaSmartPlugSwitch(MijiaSmartPlugEntity, SwitchEntity):
    _attr_name = None

    def __init__(self, coordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_switch"

    @property
    def is_on(self) -> bool | None:
        return self.coordinator.data.get("on")

    async def async_turn_on(self, **kwargs) -> None:
        await self.coordinator.async_set_on(True)

    async def async_turn_off(self, **kwargs) -> None:
        await self.coordinator.async_set_on(False)
