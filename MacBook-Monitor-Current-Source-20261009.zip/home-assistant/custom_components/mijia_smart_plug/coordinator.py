from __future__ import annotations

from datetime import timedelta
from typing import Any

from miio import MiotDevice
from miio.exceptions import DeviceException

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import DOMAIN


class MijiaSmartPlugCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    def __init__(self, hass: HomeAssistant, device: MiotDevice, name: str) -> None:
        super().__init__(
            hass,
            logger=__import__("logging").getLogger(__name__),
            name=f"{DOMAIN}_{name}",
            update_interval=timedelta(seconds=15),
        )
        self.device = device

    def _read(self) -> dict[str, Any]:
        result = self.device.get_properties_for_mapping(max_properties=10)
        return {
            item.get("did"): item.get("value")
            for item in result
            if item.get("code", 0) == 0
        }

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            return await self.hass.async_add_executor_job(self._read)
        except (DeviceException, OSError) as error:
            raise UpdateFailed(str(error)) from error

    async def async_set_on(self, value: bool) -> None:
        try:
            await self.hass.async_add_executor_job(self.device.set_property, "on", value)
        except (DeviceException, OSError) as error:
            raise UpdateFailed(str(error)) from error
        await self.async_request_refresh()
