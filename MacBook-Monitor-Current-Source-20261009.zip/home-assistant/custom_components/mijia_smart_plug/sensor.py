from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfEnergy, UnitOfPower, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import CONF_MAC, DOMAIN
from .entity import MijiaSmartPlugEntity


@dataclass(frozen=True, kw_only=True)
class PlugSensorDescription(SensorEntityDescription):
    value_fn: Callable[[object], object]


SENSORS = (
    PlugSensorDescription(
        key="power",
        name="Power",
        device_class=SensorDeviceClass.POWER,
        native_unit_of_measurement=UnitOfPower.WATT,
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda value: value,
    ),
    PlugSensorDescription(
        key="energy",
        name="Energy",
        device_class=SensorDeviceClass.ENERGY,
        native_unit_of_measurement=UnitOfEnergy.KILO_WATT_HOUR,
        state_class=SensorStateClass.TOTAL_INCREASING,
        suggested_display_precision=2,
        value_fn=lambda value: round(float(value) * 0.01, 2),
    ),
    PlugSensorDescription(
        key="temperature",
        name="Device temperature",
        device_class=SensorDeviceClass.TEMPERATURE,
        native_unit_of_measurement=UnitOfTemperature.CELSIUS,
        state_class=SensorStateClass.MEASUREMENT,
        value_fn=lambda value: value,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        MijiaSmartPlugSensor(coordinator, entry, description)
        for description in SENSORS
    )


class MijiaSmartPlugSensor(MijiaSmartPlugEntity, SensorEntity):
    entity_description: PlugSensorDescription

    def __init__(self, coordinator, entry, description) -> None:
        super().__init__(coordinator, entry)
        self.entity_description = description
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_{description.key}"

    @property
    def native_value(self):
        value = self.coordinator.data.get(self.entity_description.key)
        if value is None:
            return None
        return self.entity_description.value_fn(value)
