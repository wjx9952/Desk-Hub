from miio import MiotDevice

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_TOKEN, Platform
from homeassistant.core import HomeAssistant

from .const import CONF_NAME, CONF_MODEL, DOMAIN, PROPERTY_MAPPING
from .coordinator import MijiaSmartPlugCoordinator

PLATFORMS = [Platform.SWITCH, Platform.SENSOR]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    device = await hass.async_add_executor_job(
        lambda: MiotDevice(
            entry.data[CONF_HOST],
            entry.data[CONF_TOKEN],
            model=entry.data[CONF_MODEL],
            mapping=PROPERTY_MAPPING,
        )
    )
    coordinator = MijiaSmartPlugCoordinator(hass, device, entry.data[CONF_NAME])
    await coordinator.async_config_entry_first_refresh()
    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unloaded
