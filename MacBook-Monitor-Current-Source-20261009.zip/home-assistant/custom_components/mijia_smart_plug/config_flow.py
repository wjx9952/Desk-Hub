from __future__ import annotations

from typing import Any

from miio import MiotDevice
from miio.exceptions import DeviceException
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_TOKEN
from homeassistant.core import HomeAssistant
from homeassistant.data_entry_flow import FlowResult

from .const import (
    CONF_MAC,
    CONF_MODEL,
    CONF_NAME,
    DEFAULT_NAME,
    DOMAIN,
    PROPERTY_MAPPING,
)


def _read_device(host: str, token: str):
    device = MiotDevice(host, token, mapping=PROPERTY_MAPPING)
    info = device.info()
    device.get_properties_for_mapping(max_properties=10)
    return info


async def _validate(hass: HomeAssistant, host: str, token: str):
    return await hass.async_add_executor_job(_read_device, host, token)


class MijiaSmartPlugConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            host = user_input[CONF_HOST].strip()
            token = user_input[CONF_TOKEN].strip()
            try:
                info = await _validate(self.hass, host, token)
            except (DeviceException, OSError, ValueError):
                errors["base"] = "cannot_connect"
            else:
                mac = info.mac_address
                await self.async_set_unique_id(mac)
                self._abort_if_unique_id_configured()
                return self.async_create_entry(
                    title=user_input[CONF_NAME].strip() or DEFAULT_NAME,
                    data={
                        CONF_NAME: user_input[CONF_NAME].strip() or DEFAULT_NAME,
                        CONF_HOST: host,
                        CONF_TOKEN: token,
                        CONF_MODEL: info.model,
                        CONF_MAC: mac,
                    },
                )

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Required(CONF_NAME, default=DEFAULT_NAME): str,
                    vol.Required(CONF_HOST): str,
                    vol.Required(CONF_TOKEN): vol.All(
                        str, vol.Length(min=32, max=32)
                    ),
                }
            ),
            errors=errors,
        )
