from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import CONF_MAC, CONF_MODEL, CONF_NAME, DOMAIN
from .coordinator import MijiaSmartPlugCoordinator


class MijiaSmartPlugEntity(CoordinatorEntity[MijiaSmartPlugCoordinator]):
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: MijiaSmartPlugCoordinator,
        entry: ConfigEntry,
    ) -> None:
        super().__init__(coordinator)
        self._entry = entry
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.data[CONF_MAC])},
            name=entry.data[CONF_NAME],
            manufacturer="Xiaomi / CUCO",
            model=entry.data[CONF_MODEL],
        )
