from homeassistant.components.number import NumberEntity, NumberEntityDescription
from homeassistant.const import PERCENTAGE

from .const import CONF_MAC, DOMAIN
from .entity import MijiaSmartCameraEntity


async def async_setup_entry(hass, entry, async_add_entities) -> None:
    async_add_entities([MijiaSmartCameraVolume(hass.data[DOMAIN][entry.entry_id], entry)])


class MijiaSmartCameraVolume(MijiaSmartCameraEntity, NumberEntity):
    _attr_name = "Speaker volume"
    _attr_native_min_value = 0
    _attr_native_max_value = 100
    _attr_native_step = 1
    _attr_native_unit_of_measurement = PERCENTAGE
    _attr_mode = "slider"

    def __init__(self, coordinator, entry) -> None:
        super().__init__(coordinator, entry)
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_speaker_volume"

    @property
    def native_value(self):
        return self.coordinator.data.get("speaker_volume")

    async def async_set_native_value(self, value: float) -> None:
        await self.coordinator.async_set_property("speaker_volume", int(value))
