from __future__ import annotations

from dataclasses import dataclass

from homeassistant.components.switch import SwitchEntity, SwitchEntityDescription
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import CONF_MAC, DOMAIN
from .entity import MijiaSmartCameraEntity


@dataclass(frozen=True, kw_only=True)
class CameraSwitchDescription(SwitchEntityDescription):
    pass


SWITCHES = (
    CameraSwitchDescription(key="camera_switch", name="Camera"),
    CameraSwitchDescription(key="motion_detection", name="Motion detection"),
    CameraSwitchDescription(key="human_detection", name="Human detection"),
    CameraSwitchDescription(key="human_tracking", name="Human tracking"),
    CameraSwitchDescription(key="move_detection", name="Movement detection"),
    CameraSwitchDescription(key="pet_detection", name="Pet detection"),
    CameraSwitchDescription(key="pet_tracking", name="Pet tracking"),
    CameraSwitchDescription(key="baby_cry_detection", name="Baby cry detection"),
    CameraSwitchDescription(key="abnormal_sound_detection", name="Abnormal sound detection"),
    CameraSwitchDescription(key="human_close_up", name="Human close-up"),
    CameraSwitchDescription(key="indicator_light", name="Indicator light"),
    CameraSwitchDescription(key="time_watermark", name="Time watermark"),
    CameraSwitchDescription(key="glimmer_full_color", name="Low-light full color"),
    CameraSwitchDescription(key="speaker_mute", name="Speaker mute"),
)


async def async_setup_entry(hass, entry, async_add_entities) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(MijiaSmartCameraSwitch(coordinator, entry, desc) for desc in SWITCHES)


class MijiaSmartCameraSwitch(MijiaSmartCameraEntity, SwitchEntity):
    entity_description: CameraSwitchDescription

    def __init__(self, coordinator, entry, description) -> None:
        super().__init__(coordinator, entry)
        self.entity_description = description
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_{description.key}"

    @property
    def is_on(self) -> bool | None:
        return self.coordinator.data.get(self.entity_description.key)

    async def async_turn_on(self, **kwargs) -> None:
        await self.coordinator.async_set_property(self.entity_description.key, True)

    async def async_turn_off(self, **kwargs) -> None:
        await self.coordinator.async_set_property(self.entity_description.key, False)
