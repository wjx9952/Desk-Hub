from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from homeassistant.components.sensor import SensorEntity, SensorEntityDescription

from .const import CAMERA_STATUS, CONF_MAC, DOMAIN, SD_STATUS
from .entity import MijiaSmartCameraEntity


def _storage_gb(value):
    return round(float(value) / 1024 / 1024, 2)


@dataclass(frozen=True, kw_only=True)
class CameraSensorDescription(SensorEntityDescription):
    value_fn: Callable[[object], object]


SENSORS = (
    CameraSensorDescription(key="camera_status", name="Camera status", value_fn=lambda v: CAMERA_STATUS.get(v, f"Unknown ({v})")),
    CameraSensorDescription(key="sd_status", name="SD card status", value_fn=lambda v: SD_STATUS.get(v, f"Unknown ({v})")),
    CameraSensorDescription(key="sd_total", name="SD card total", native_unit_of_measurement="GB", suggested_display_precision=2, value_fn=_storage_gb),
    CameraSensorDescription(key="sd_free", name="SD card free", native_unit_of_measurement="GB", suggested_display_precision=2, value_fn=_storage_gb),
    CameraSensorDescription(key="sd_used", name="SD card used", native_unit_of_measurement="GB", suggested_display_precision=2, value_fn=_storage_gb),
    CameraSensorDescription(key="recording_remaining", name="Recording time remaining", value_fn=lambda v: v),
    CameraSensorDescription(key="people_number", name="People detected", value_fn=lambda v: v),
    CameraSensorDescription(key="ptz_supported", name="Pan/tilt supported", value_fn=lambda v: "Yes" if v else "No"),
)


async def async_setup_entry(hass, entry, async_add_entities) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(MijiaSmartCameraSensor(coordinator, entry, desc) for desc in SENSORS)


class MijiaSmartCameraSensor(MijiaSmartCameraEntity, SensorEntity):
    entity_description: CameraSensorDescription

    def __init__(self, coordinator, entry, description) -> None:
        super().__init__(coordinator, entry)
        self.entity_description = description
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_{description.key}"

    @property
    def native_value(self):
        value = self.coordinator.data.get(self.entity_description.key)
        return None if value is None else self.entity_description.value_fn(value)
