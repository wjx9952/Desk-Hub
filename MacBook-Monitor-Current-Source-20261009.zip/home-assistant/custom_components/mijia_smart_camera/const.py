DOMAIN = "mijia_smart_camera"
DEFAULT_NAME = "Xiaomi Smart Camera 4 4K"
CONF_NAME = "name"
CONF_MODEL = "model"
CONF_MAC = "mac"

PROPERTY_MAPPING = {
    "camera_switch": {"siid": 2, "piid": 1},
    "ptz_supported": {"siid": 2, "piid": 2},
    "night_shot": {"siid": 2, "piid": 3},
    "time_watermark": {"siid": 2, "piid": 5},
    "glimmer_full_color": {"siid": 2, "piid": 7},
    "human_tracking": {"siid": 2, "piid": 9},
    "camera_status": {"siid": 2, "piid": 18},
    "indicator_light": {"siid": 3, "piid": 1},
    "sd_status": {"siid": 4, "piid": 1},
    "sd_total": {"siid": 4, "piid": 2},
    "sd_free": {"siid": 4, "piid": 3},
    "sd_used": {"siid": 4, "piid": 4},
    "recording_remaining": {"siid": 4, "piid": 6},
    "motion_detection": {"siid": 5, "piid": 1},
    "motion_sensitivity": {"siid": 5, "piid": 3},
    "speaker_volume": {"siid": 6, "piid": 1},
    "speaker_mute": {"siid": 6, "piid": 2},
    "pet_detection": {"siid": 8, "piid": 5},
    "human_detection": {"siid": 8, "piid": 8},
    "move_detection": {"siid": 8, "piid": 9},
    "baby_cry_detection": {"siid": 8, "piid": 10},
    "pet_tracking": {"siid": 8, "piid": 21},
    "human_close_up": {"siid": 8, "piid": 24},
    "people_number": {"siid": 8, "piid": 30},
    "abnormal_sound_detection": {"siid": 8, "piid": 32},
}

CAMERA_STATUS = {
    0: "Calls and pan/tilt available",
    1: "Calls available; pan/tilt unavailable",
    2: "Pan/tilt available; calls unavailable",
}

SD_STATUS = {
    0: "Normal",
    1: "Not present",
    2: "Full",
    3: "Damaged",
    4: "Formatting",
    5: "Ejected",
    6: "Repairing",
    7: "Ejecting",
    8: "Uninitialized",
    9: "Insufficient space",
    10: "Abnormal files",
    11: "Incompatible",
}
