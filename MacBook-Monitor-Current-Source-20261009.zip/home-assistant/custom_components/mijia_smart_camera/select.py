from __future__ import annotations

from dataclasses import dataclass

from homeassistant.components.select import SelectEntity, SelectEntityDescription
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import CONF_MAC, DOMAIN
from .entity import MijiaSmartCameraEntity


@dataclass(frozen=True, kw_only=True)
class CameraSelectDescription(SelectEntityDescription):
    values: dict[int, str]


SELECTS = (
    CameraSelectDescription(
        key="night_shot", name="Night vision", values={0: "On", 1: "Off", 2: "Auto"}
    ),
    CameraSelectDescription(
        key="motion_sensitivity", name="Motion sensitivity", values={0: "Low", 1: "Medium", 2: "High"}
    ),
)


async def async_setup_entry(hass, entry, async_add_entities) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(MijiaSmartCameraSelect(coordinator, entry, desc) for desc in SELECTS)


class MijiaSmartCameraSelect(MijiaSmartCameraEntity, SelectEntity):
    entity_description: CameraSelectDescription

    def __init__(self, coordinator, entry, description) -> None:
        super().__init__(coordinator, entry)
        self.entity_description = description
        self._attr_unique_id = f"{entry.data[CONF_MAC]}_{description.key}"
        self._attr_options = list(description.values.values())

    @property
    def current_option(self) -> str | None:
        value = self.coordinator.data.get(self.entity_description.key)
        return self.entity_description.values.get(value)

    async def async_select_option(self, option: str) -> None:
        value = next(k for k, v in self.entity_description.values.items() if v == option)
        await self.coordinator.async_set_property(self.entity_description.key, value)
