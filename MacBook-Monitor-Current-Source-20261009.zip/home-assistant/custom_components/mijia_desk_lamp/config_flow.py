from __future__ import annotations

from typing import Any

from miio.exceptions import DeviceException
from miio.integrations.light.yeelight.yeelight import Yeelight
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.const import CONF_HOST, CONF_TOKEN
from homeassistant.core import HomeAssistant
from homeassistant.data_entry_flow import FlowResult

from .const import CONF_NAME, DEFAULT_NAME, DOMAIN


def _read_status(host: str, token: str) -> None:
    Yeelight(host, token).status()


async def _validate(hass: HomeAssistant, host: str, token: str) -> None:
    await hass.async_add_executor_job(_read_status, host, token)


class MijiaDeskLampConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        errors: dict[str, str] = {}
        if user_input is not None:
            host = user_input[CONF_HOST].strip()
            token = user_input[CONF_TOKEN].strip()
            try:
                await _validate(self.hass, host, token)
            except (DeviceException, OSError, ValueError):
                errors["base"] = "cannot_connect"
            else:
                await self.async_set_unique_id(host)
                self._abort_if_unique_id_configured()
                return self.async_create_entry(
                    title=user_input[CONF_NAME].strip() or DEFAULT_NAME,
                    data={CONF_HOST: host, CONF_TOKEN: token},
                )

        schema = vol.Schema(
            {
                vol.Required(CONF_NAME, default=DEFAULT_NAME): str,
                vol.Required(CONF_HOST): str,
                vol.Required(CONF_TOKEN): vol.All(str, vol.Length(min=32, max=32)),
            }
        )
        return self.async_show_form(step_id="user", data_schema=schema, errors=errors)
