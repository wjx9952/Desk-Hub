from __future__ import annotations

from datetime import timedelta
from functools import partial
from typing import Any

from miio.exceptions import DeviceException
from miio.integrations.light.yeelight.yeelight import Yeelight

from homeassistant.components.light import (
    ATTR_BRIGHTNESS,
    ATTR_COLOR_TEMP_KELVIN,
    ColorMode,
    LightEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_HOST, CONF_TOKEN
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN, MAX_COLOR_TEMP_KELVIN, MIN_COLOR_TEMP_KELVIN

SCAN_INTERVAL = timedelta(seconds=10)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    lamp = await hass.async_add_executor_job(
        Yeelight, entry.data[CONF_HOST], entry.data[CONF_TOKEN]
    )
    async_add_entities([MijiaDeskLamp(entry, lamp)], update_before_add=True)


class MijiaDeskLamp(LightEntity):
    _attr_color_mode = ColorMode.COLOR_TEMP
    _attr_supported_color_modes = {ColorMode.COLOR_TEMP}
    _attr_min_color_temp_kelvin = MIN_COLOR_TEMP_KELVIN
    _attr_max_color_temp_kelvin = MAX_COLOR_TEMP_KELVIN

    def __init__(self, entry: ConfigEntry, lamp: Yeelight) -> None:
        self._entry = entry
        self._host = entry.data[CONF_HOST]
        self._lamp = lamp
        self._attr_name = entry.title
        self._attr_unique_id = f"{self._host}_light"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, self._host)},
            name=entry.title,
            manufacturer="Xiaomi / Yeelight",
            model="Mijia Desk Lamp 1S (yeelink.light.lamp4)",
        )

    async def _command(self, method, *args) -> bool:
        try:
            await self.hass.async_add_executor_job(partial(method, *args))
        except (DeviceException, OSError):
            self._attr_available = False
            self.async_write_ha_state()
            return False
        self._attr_available = True
        return True

    async def async_turn_on(self, **kwargs: Any) -> None:
        if not await self._command(self._lamp.on):
            return

        if ATTR_BRIGHTNESS in kwargs:
            percent = max(1, min(100, round(kwargs[ATTR_BRIGHTNESS] * 100 / 255)))
            await self._command(self._lamp.set_brightness, percent)

        if ATTR_COLOR_TEMP_KELVIN in kwargs:
            kelvin = max(
                MIN_COLOR_TEMP_KELVIN,
                min(MAX_COLOR_TEMP_KELVIN, int(kwargs[ATTR_COLOR_TEMP_KELVIN])),
            )
            await self._command(self._lamp.set_color_temp, kelvin)

        await self.async_update()
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        if await self._command(self._lamp.off):
            self._attr_is_on = False
            self.async_write_ha_state()

    async def async_update(self) -> None:
        try:
            status = await self.hass.async_add_executor_job(self._lamp.status)
        except (DeviceException, OSError):
            self._attr_available = False
            return

        self._attr_available = True
        self._attr_is_on = status.is_on
        self._attr_brightness = max(0, min(255, round(status.brightness * 255 / 100)))
        color_temp = status.color_temp
        if color_temp:
            self._attr_color_temp_kelvin = max(
                MIN_COLOR_TEMP_KELVIN,
                min(MAX_COLOR_TEMP_KELVIN, int(color_temp)),
            )
